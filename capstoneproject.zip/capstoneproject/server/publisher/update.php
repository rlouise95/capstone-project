<?php 
	
	require '../../classes/class.model.php';
	require '../../classes/class.view.php';
	require '../../classes/class.controller.php';

	$id = $_POST['id'];



	$publisher = View::fetchSinglePublisher([
		'publisher_id' => $id
	]);

?>

<input class="form-control" type="text" name="publisherName" value="<?= $publisher->publisher_name; ?>">
<input class="form-control" type="hidden" name="publisherId" value="<?= $publisher->publisher_id; ?>">