<?php 

	require '../../classes/class.model.php';
	require '../../classes/class.view.php';
	require '../../classes/class.controller.php';

	$fetchRules = View::fetchRules(['id' => 1]);

	$accesion = $_POST['accession'];

	$fetchBookBorrowers = View::fetchBookBorrowers([
		'accession_id' => $accesion
	]);


?>



<table class="table text-start table-striped table-hover">
  <thead>
    <tr>
      <th>ID number</th>
      <th>Name</th>
      <th>Department</th>
      <th>Contact</th>
      <th>Type</th>
      <th>Borrowed Date</th>
      <th>Due Date</th>
      <th>Over Due Date</th>
      <th>Fines</th>
    </tr>
  </thead>

  <tbody>

  	<?php foreach($fetchBookBorrowers as $borrowers) : ?>

  	<?php 

  		$today = strtotime(date('Y-m-d')); 

  		$due_date = strtotime($borrowers->due_date); 

  		$sub = $today - $due_date;

  		$days = 60 * 60 * 24;

  		if($today < $due_date){
  			$penalty = 0;
  		} else {
  			$penalty = abs(floor($sub / $days));
  		}

  	?>

    <tr>
      <td><?= $borrowers->idnumber; ?></td>
      <td><?= ucwords($borrowers->lastname.', '.$borrowers->firstname.' '.$borrowers->middlename); ?></td>
      <td><?= $borrowers->department_name; ?></td>
      <td><?= $borrowers->contactnumber; ?></td>
      <td><?= $borrowers->type; ?></td>
      <td><?= $borrowers->semester.'Sem / '.$borrowers->borrowed_date; ?></td>
      <td><?= $borrowers->semester.'Sem / '.$borrowers->due_date; ?></td>
      <td><?= $penalty.' days'; ?></td>
      <td><?= $penalty * $fetchRules->overdue_penalty; ?></td>
    </tr>

	<?php endforeach; ?>
       
  </tbody>
</table>