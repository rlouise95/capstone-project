<?php 

require '../../classes/class.model.php';
require '../../classes/class.view.php';
require '../../classes/class.controller.php';

$category = $_POST['category'];
$type = $_POST['type'];



$fetchAllCategoryBooks = View::fetchAllCategoryBooks([
	'books.category_id' => (int)$category,
	'books.type' => $type,
	'books.broadcast' => 1
]);



$countBookCategory = View::countBookCategory([
	'books.category_id' => $category,
	'type' => $type,
	'broadcast' => 1
]);

?>


<?php if($countBookCategory > 0) : ?>

<div class="shelve">
	
	<h3 class="category-title text-start"><?= $fetchAllCategoryBooks[0]->category_name; ?></h3>


	<div class="books">

	<?php foreach($fetchAllCategoryBooks as $book) : ?>

		<div class="book">

			<?php if($book->status != 'On-stock') : ?>

			<span style="background-color: #de9817;width:150px;text-align: center; color: white;"><?= $book->status;?></span>

			<?php else: ?>

			<span style="background-color: #49c749;width:150px;text-align: center; color: white;"><?= $book->status;?></span>

			<?php endif; ?>

			<img class="book-cover" src="images/book/<?= $book->image; ?>">

			<?php if($book->status != 'On-stock') : ?>

				<span style="font-weight: bold;">Not available</span>

			<?php elseif($book->availablecopies == 0) : ?>

				<span style="font-weight: bold;">Borrowed</span>

			<?php else: ?>

				<span style="font-weight: bold;">Available</span>

			<?php endif; ?>
			
		
			<a class="button btn btn-sm text-light" target="_blank" href="opac-singlepage?id=<?= $book->accession_id; ?>">info</a>
		</div>
		
	<?php endforeach; ?>

	</div>

</div>

<?php endif; ?>



