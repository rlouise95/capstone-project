<?php 

require '../../classes/class.model.php';
require '../../classes/class.view.php';
require '../../classes/class.controller.php';

$fetchCategories = View::fetchCategories();

$category = $_POST['category'];
$filterkey = $_POST['filterkey'];
$searchkey = $_POST['searchkey'];



	
	if($category != 'All'){ 

			if($filterkey != 'Publisher'){

				$searchBooks = View::searchCirculationBook([
					'categories.category_id' => $category,
					'filterkey' => strtolower($filterkey),
					'searchkey' => strtolower($searchkey),
					'books.broadcast' => 1
				]);

			} else {

				$allBooks = View::fetchBooks();

				$filter = array_filter($allBooks, function($book){
					if($book->broadcast == 1 && $book->type == 'Circulation'){
						return $book;
					}
				});

				$searchBooks = array_filter($filter, function($book){
					if($book->publisher_name == ucwords($_POST['searchkey']) && $book->category_id == $_POST['category']){
						return $book;
					}
				});			
			}

	} else {


		if($filterkey != 'Publisher'){

			$searchBooks = View::searchAllCirculationBook([
				'filterkey' => strtolower($filterkey),
				'searchkey' => strtolower($searchkey),
				'books.broadcast' => 1
			]);

		} else {

			$allBooks = View::fetchBooks();

			$filter = array_filter($allBooks, function($book){
				if($book->broadcast == 1 && $book->type == 'Circulation'){
					return $book;
				}
			});

			$searchBooks = array_filter($filter, function($book){
				if($book->publisher_name == ucwords($_POST['searchkey'])){
					return $book;
				}
			});			

		}

	}

?>


<div class="shelve">
			
		<?php foreach($fetchCategories as $cat) : ?>
			<?php if($cat->category_id == $category) : ?>
				<h3 class="category-title text-start"><?= $cat->category_name; ?></h3>
			<?php endif; ?>
		<?php endforeach; ?>

		<div class="books" style="border-bottom: 0;">

			<?php foreach($searchBooks as $book) : ?>

			<div class="book">

				<?php if($book->status != 'On-stock') : ?>

				<span style="background-color: #de9817;width:150px;text-align: center; color: white;"><?= $book->status;?></span>

				<?php else: ?>

				<span style="background-color: #49c749;width:150px;text-align: center; color: white;"><?= $book->status;?></span>

				<?php endif; ?>

				<img class="book-cover" src="images/book/<?= $book->image; ?>">

				<?php if($book->status != 'On-stock') : ?>

					<span style="font-weight: bold;">Not available</span>

				<?php elseif($book->availablecopies == 0) : ?>

					<span style="font-weight: bold;">Borrowed</span>

				<?php else: ?>

					<span style="font-weight: bold;">Available</span>

				<?php endif; ?>
				
			
				<a class="button btn btn-sm text-light" target="_blank" href="opac-singlepage?id=<?= $book->accession_id; ?>">info</a>
			</div>

			<?php endforeach; ?>

		</div>

	</div>


