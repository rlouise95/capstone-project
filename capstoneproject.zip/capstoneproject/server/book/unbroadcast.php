<?php 

	require '../../classes/class.model.php';
	require '../../classes/class.view.php';
	require '../../classes/class.controller.php';

	$accession = $_POST['accession'];

	$broadcastBook = Controller::broadcastBook([
		'broadcast' => 0
	], ['accession_id' => $accession]);