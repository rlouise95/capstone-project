<?php 

	require '../../classes/class.model.php';
	require '../../classes/class.view.php';
	require '../../classes/class.controller.php';

	$accession = $_POST['accession'];

	$fetchPublishers = View::fetchPublishers();

	$fetchCategories = View::fetchCategories();

	$fetchbook = View::fetchSingleBook([
		'accession_id' => $accession
	]);

	?>

	<div class="col-lg-6">
			<div class="form-floating mb-2">
				<input type="number" class="form-control accession" id="floatingInput" required autocomplete="off" value="<?= $fetchbook->accession_id; ?>" disabled>
				<label for="floatingInput">Accession number</label>
			</div>

			<div class="form-floating mb-2">
				<input type="number" class="form-control ddc" id="floatingPassword" required autocomplete="off" value="<?= $fetchbook->ddc; ?>">
				<label for="floatingPassword">DDC</label>
			</div>

			<div class="form-floating mb-2">
				<input type="text" class="form-control author" id="floatingPassword" required autocomplete="off" value="<?= $fetchbook->author; ?>">
				<label for="floatingPassword">Author</label>
			</div>

			<div class="form-floating mb-2">
				<input type="text" class="form-control title" id="floatingPassword" required autocomplete="off" value="<?= $fetchbook->title; ?>">
				<label for="floatingPassword">Title</label>
			</div>

			<div class="form-floating mb-2">
				<input type="number" class="form-control edition" id="floatingPassword" required autocomplete="off" value="<?= $fetchbook->edition; ?>">
				<label for="floatingPassword">Edition number</label>
			</div>

			<div class="form-floating mb-2">
				<input type="text" class="form-control placeofpublication" id="floatingPassword" required autocomplete="off" value="<?= $fetchbook->placeofpublication; ?>">
				<label for="floatingPassword">Place of publication</label>
			</div>	

						  	    
		</div>




		<div class="col-lg-6 text-start">
			<div class="mb-3">
			  <label> PUBLISHER </label>
			  <br>
			  <select class="form-select mb-3 mt-1 publisher">
			  		<option value="<?= $fetchbook->publisher_id; ?>"><?= $fetchbook->publisher_name; ?></option>
				  <?php foreach($fetchPublishers as $publisher) : ?>
				  	<option value="<?= $publisher->publisher_id; ?>"><?= $publisher->publisher_name; ?></option>
				  <?php endforeach; ?>
				</select>
			</div>
			<div class="mb-3">
			  <label> CATEGORY </label>
			  <br>
			  <select class="form-select mb-3 mt-1 category">
			  		<option value="<?= $fetchbook->category_id; ?>"><?= $fetchbook->category_name; ?></option>
				  <?php foreach($fetchCategories as $category) : ?>
				  	<option value="<?= $category->category_id; ?>"><?= $category->category_name; ?></option>
				  <?php endforeach; ?>
				</select>
			</div>
			<div class="mb-2">
				<label> COPYRIGHT DATE </label>
			  	<br>
				<select class="form-select copyrightdate" required>
					<option><?= $fetchbook->copyrightdate; ?></option>
				 <?php for ($year = (int)date('Y'); 1900 <= $year; $year--): ?>
					   <option value="<?=$year;?>"><?=$year;?></option>
				 <?php endfor; ?>
				</select>
			</div>
			<div class="mb-3">
			  <label> BOOK STATUS </label>
			  <br>
			  <select class="form-select mb-3 mt-1 status">
			  	 <option><?= $fetchbook->status; ?></option>
				  <option>On-stock</option>
				  <option>For purchased</option>
				</select>
			</div>
			<div class="mb-3">
			  <label> BOOK TYPE </label>
			  <br>
			  <select class="form-select mb-3 mt-1 type">
			  	<option><?= $fetchbook->type; ?></option>
				  <option>Circulation</option>
				  <option>Reserved</option>
				</select>
			</div>
			<div class="form-group py-1">
				<label> BOOK IMAGE </label>
				<input type="file"  class="form-control mt-1 image" required>
			</div>
			<input type="hidden" value="<?= $fetchbook->image; ?>">
			<input type="hidden" value="<?= $fetchbook->borrowedcopies; ?>">
		</div>






	




