<?php 

require '../../classes/class.model.php';
require '../../classes/class.view.php';
require '../../classes/class.controller.php';

$fetchCategories = View::fetchCategories();

$fetchPublishers = View::fetchPublishers();


$category = $_POST['category'];
$accession = $_POST['accession'];
$ddc = $_POST['ddc'];
$author = $_POST['author'];
$title = $_POST['title'];
$edition = $_POST['edition'];
$placeofpublication = $_POST['placeofpublication'];
$publisher = $_POST['publisher'];
$copyrightdate = $_POST['copyrightdate'];
// $copies = $_POST['copies'];
$status = $_POST['status'];
$type = $_POST['type'];


		$countBook = View::countBook([
			'accession_id' => $accession
		]);

		if($countBook > 0){

			$error['accession'] = 'Accession number already exist!';


		} else {

			if(!preg_match("/^[a-zA-Z ]*$/", $author)){
          		$error['author'] = 'Invalid characters!';
      		}

      		if(!preg_match("/^[a-zA-Z1-9 ]*$/", $title)){
          		$error['title'] = 'Invalid characters!';
      		}


      		// if(!preg_match("/^[a-zA-Z1-9 ]*$/", $placeofpublication)){
        //   		$error['placeofpublication'] = 'Invalid characters!';
      		// }


      		if(empty($error)){



      				$image = $_FILES['file-0'];
      				$getExt = pathinfo($image['name']);

      				if(in_array($getExt['extension'], array('jpg','png','jpeg'))){
      					if($image['error'] == 0 && $image['size'] < 100000000){

      						$newname = $accession.'-'.$title.'.'.$getExt['extension'];
      						$destination = '../../images/book/'.$newname;
      						move_uploaded_file($image['tmp_name'], $destination);

      						$insertBook = Controller::insertBook([
      							'accession_id' => (int)$accession,
      							'category_id' => (int)$category,
      							'ddc' => (int)$ddc,
      							'author' => $author,
      							'title' => $title,
      							'edition' => $edition,
      							'placeofpublication' => $placeofpublication,
      							'publisher_id' => (int)$publisher,
      							'copyrightdate' => $copyrightdate,
      							'totalcopies' => 1,
      							'availablecopies' => 1,
      							'status' => $status,
      							'type' => $type,
      							'image' => $newname
      						]);

      						$success = 1;

      					} else {
      						$imageError['image'] = 'Theres an error of this file!';	
      					}
      				} else {
      					$imageError['format'] = 'Invalid file format!';	
      				}

      			


      		}


		}

?>


<?php if(!isset($success)) : ?>
	


<div class="col-lg-6">
	<div class="form-floating mb-2">
		<input type="number" class="form-control accession" id="floatingInput" required value="<?= $accession; ?>">
		<label for="floatingInput">Accession number</label>
		<small class="text-danger"><?= $error['accession'] ?? '' ?></small>
	</div>

	<div class="form-floating mb-2">
		<input type="number" class="form-control ddc" id="floatingPassword" required value="<?= $ddc; ?>" disabled>
		<label for="floatingPassword">DDC</label>
	</div>

	<div class="form-floating mb-2">
		<input type="text" class="form-control author" id="floatingPassword" required value="<?= $author; ?>" disabled>
		<label for="floatingPassword">Author</label>
		<small class="text-danger"><?= $error['author'] ?? '' ?></small>
	</div>

	<div class="form-floating mb-2">
		<input type="text" class="form-control title" id="floatingPassword" required value="<?= $title; ?>" disabled>
		<label for="floatingPassword">Title</label>
		<small class="text-danger"><?= $error['title'] ?? '' ?></small>
	</div>

	<div class="form-floating mb-2">
		<input type="number" class="form-control edition" id="floatingPassword" required value="<?= $edition; ?>" disabled>
		<label for="floatingPassword">Edition number</label>
	</div>

	<div class="form-floating mb-2">
		<input type="text" class="form-control placeofpublication" id="floatingPassword" required value="<?= $placeofpublication; ?>" disabled>
		<label for="floatingPassword">Place of publication</label>
	</div>	
	  	    
</div>



<div class="col-lg-6">
	<div class="mb-3">
	  <label> PUBLISHER </label>
	  <br>
	  <select class="form-select mb-3 mt-1 publisher" disabled>
	  	<?php foreach($fetchPublishers as $pub) : ?>
	  			<?php if($pub->publisher_id == $publisher) : ?>
	  				<option value="<?= $pub->publisher_id; ?>" class="selected"><?= $pub->publisher_name; ?></option>
	  			<?php endif; ?>
	  	<?php endforeach; ?>

		  <?php foreach($fetchPublishers as $publisher) : ?>
		  	<option value="<?= $publisher->publisher_id; ?>"><?= $publisher->publisher_name; ?></option>
		  <?php endforeach; ?>
		</select>
	</div>


	<div class="mb-3">
	  <label> CATEGORY </label>
	  <br>
	  <select class="form-select mb-3 mt-1 category" disabled>
	  		<?php foreach($fetchCategories as $cat) : ?>
	  				<?php if($cat->category_id == $category) : ?>
	  					<option value="<?= $cat->category_id; ?>" class="selected"><?= $cat->category_name; ?></option>
	  				<?php endif; ?>
	  		<?php endforeach; ?>

		  <?php foreach($fetchCategories as $category) : ?>
		  	<option value="<?= $category->category_id; ?>"><?= $category->category_name; ?></option>
		  <?php endforeach; ?>
		</select>
	</div>


	<div class="mb-2">
		<label> COPYRIGHT DATE </label>
	  	<br>
		<select class="form-select copyrightdate" required disabled>
			<option class="selected"><?= $copyrightdate; ?></option>
		 <?php for ($year = (int)date('Y'); 1900 <= $year; $year--): ?>
			   <option value="<?=$year;?>"><?=$year;?></option>
		 <?php endfor; ?>
		</select>
	</div>


	<div class="mb-3">
	  <label> BOOK STATUS </label>
	  <br>
	  <select class="form-select mb-3 mt-1 status" disabled>
	  	<option class="selected"><?= $status; ?></option>
		  <option>On-stock</option>
		  <option>For purchased</option>
		</select>
	</div>


	<div class="mb-3">
	  <label> BOOK TYPE </label>
	  <br>
	  <select class="form-select mb-3 mt-1 type" disabled>
	  	<option class="selected"><?= $type; ?></option>
		  <option>Circulation</option>
		  <option>Reserved</option>
		</select>
	</div>


	<div class="form-group py-1">
		<label> BOOK IMAGE </label>
		<input type="file"  class="form-control mt-1 image" required>
		<small class="text-danger"><?= $imageError['image'] ?? '' ?></small>
		<small class="text-danger"><?= $imageError['format'] ?? '' ?></small>
	</div>
</div>


<?php endif; ?>


<script>
	<?php if(isset($success)) : ?>

		$('#allBookCopyModal').modal('hide');
		$('#circulationBookCopyModal').modal('hide');
		$('#reservedBookCopyModal').modal('hide');
		alert('NEW BOOK COPY SUCCESSFULLY ADDED!');
		window.location.href = 'admin-maintenance';

	<?php endif; ?>
</script>








