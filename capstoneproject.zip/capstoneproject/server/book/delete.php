<?php 
	
	require '../../classes/class.model.php';
	require '../../classes/class.view.php';
	require '../../classes/class.controller.php';

	$accession = $_POST['accession'];

	$deleteBookImage = View::fetchSingleBook([
		'accession_id' => $accession
	]);

	unlink('../../images/book/'.$deleteBookImage->image);

	$book = Controller::deleteBook([
		'accession_id' => $accession
	]);

?>




