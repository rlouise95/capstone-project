<?php 

require '../../classes/class.model.php';
require '../../classes/class.view.php';
require '../../classes/class.controller.php';

$accession = $_POST['accession'];

$fetchCategories = View::fetchCategories();

// $fetchPublishers = View::fetchPublishers();

$fetchbook = View::fetchSingleBook([
    'accession_id' => $accession
]);


?>
<div class="d-flex flex-column align-items-center p-0  col-4">


        <img class=" h-50 w-50 mb-2" src="images/book/<?= $fetchbook->image; ?>">

         <div class="d-flex flex-column w-100 justify-content-center">
            <p class="m-0"><?= $fetchbook->accession_id; ?></p> 
             <label style="font-weight: bolder;">Accession number:</label>
             
         </div>
</div>

<div id="info" class="col-8 h-100 row p-0 overflow-auto">

    <div class="col-lg-3 p-0" style="font-size: 14px;">
        <div class="d-flex">
            <label style="font-weight: bolder;">Category:</label>
       
        </div>
        <div class="d-flex">
            <label style="font-weight: bolder;">DDC:</label>
       
        </div>
        <div class="d-flex">
            <label style="font-weight: bolder;">Author:</label>
          
        </div>
        <div class="d-flex">
            <label style="font-weight: bolder;">Title:</label>

        </div>
        <div class="d-flex">
            <label style="font-weight: bolder;">Edition:</label>
          
        </div>
        <div class="d-flex">
            <label style="font-weight: bolder;">Place Publication:</label>
          
        </div>
        <div class="d-flex">
            <label style="font-weight: bolder;">Publisher:</label>
          
        </div>
        <div class="d-flex">
            <label style="font-weight: bolder;">Copyright date:</label>
     
        </div>
        
        <div class="d-flex">
            <label style="font-weight: bolder;">Status:</label>
       
        </div>
        <div class="d-flex">
            <label style="font-weight: bolder;">Type:</label>
       
        </div>
        <div class="d-flex">
            <label style="font-weight: bolder;">Date added:</label>
        
        </div>
    </div>

    <div class="col-lg-9 p-0" style="font-size: 14px;">
        <div class="d-flex">
            
            <p class="mx-2 my-0"><?= $fetchbook->category_name; ?></p>
        </div>
        <div class="d-flex">
           
            <p class="mx-2 my-0"><?= $fetchbook->ddc; ?></p>
        </div>
        <div class="d-flex">
           
            <p class="mx-2 my-0"><?= $fetchbook->author; ?></p>
        </div>
        <div class="d-flex">
         
            <p class="mx-2 my-0"><?= $fetchbook->title; ?></p>
        </div>
        <div class="d-flex">
      
            <p class="mx-2 my-0"><?= $fetchbook->edition; ?></p>
        </div>
        <div class="d-flex">
    
            <p class="mx-2 my-0"><?= $fetchbook->placeofpublication; ?></p>
        </div>
        <div class="d-flex">
         
            <p class="mx-2 my-0"><?= $fetchbook->publisher_name; ?></p>
        </div>
        <div class="d-flex">
   
            <p class="mx-2 my-0"><?= $fetchbook->copyrightdate; ?></p>
        </div>
        
        <div class="d-flex">
         
            <p class="mx-2 my-0"><?= $fetchbook->status; ?></p>
        </div>
        <div class="d-flex">
       
            <p class="mx-2 my-0"><?= $fetchbook->type; ?></p>
        </div>
        <div class="d-flex">
         
            <p class="mx-2 my-0"><?= $fetchbook->date_added; ?></p>
        </div>
    </div>
    
</div>