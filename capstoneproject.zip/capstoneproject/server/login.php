<?php 
	
	session_start();
	require '../classes/class.model.php';
	require '../classes/class.view.php';
	require '../classes/class.controller.php';

	$username = $_POST['username'];
	$password = $_POST['password'];

	if(!empty($username) && !empty($password)){

		$countUser = View::countUser([
		'username' => $username]
		);

		if($countUser < 1){
			$error['username'] = 'Username does not exist!';
		} else {
			
			$fetchUser = View::fetchUser([
			'username' => $username]
			);

			if(password_verify($password, $fetchUser->password)){
				
				$_SESSION['username'] = $fetchUser->username;
				$_SESSION['firstname'] = $fetchUser->firstname;
				$_SESSION['middlename'] = $fetchUser->middlename;
				$_SESSION['lastname'] = $fetchUser->lastname;
				$_SESSION['type'] = $fetchUser->type;

				$success = true;

			}else {
				$error['password'] = 'Wrong Password!';
			}

		}
	}

?>

	<div class="form-floating mb-3 w-100">
	  <input type="text" class="form-control loginUsername" id="floatingInput" placeholder="Username" required autocomplete="off" value="<?= $username; ?>">
	  <label for="floatingInput">User name</label>
		<small class="text-danger"><?= isset($error['username']) ? $error['username'] : ''; ?></small>
	</div>

	<div class="form-floating mb-3 w-100">
	  <input type="password" class="form-control loginPassword" id="floatingPassword" placeholder="Password" required autocomplete="off" value="<?= $password
	  ; ?>">
	  <label for="floatingPassword">Password</label>
	  <small class="text-danger"><?= isset($error['password']) ? $error['password'] : ''; ?></small>
	</div>


	<script>
		
		<?php if(isset($success)) : ?>
			window.location.href = 'admin-dashboard';
		<?php endif; ?>

	</script>








		

