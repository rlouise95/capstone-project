<?php 
	
	require '../../classes/class.model.php';
	require '../../classes/class.view.php';
	require '../../classes/class.controller.php';

	$id = $_POST['id'];



	$category = View::fetchSingleCategory([
		'category_id' => $id
	]);

?>

<input class="form-control" type="text" name="categoryName" value="<?= $category->category_name; ?>">
<input class="form-control" type="hidden" name="categoryId" value="<?= $category->category_id; ?>">

