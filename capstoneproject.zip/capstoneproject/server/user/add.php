<?php 

	require '../../classes/class.model.php';
	require '../../classes/class.view.php';
	require '../../classes/class.controller.php';

	$lastname = $_POST['lastname'];
	$firstname = $_POST['firstname'];
	$middlename = $_POST['middlename'];
	$type = $_POST['type'];
	$contactnumber = $_POST['contactnumber'];
	$username = $_POST['username'];
	$password = $_POST['password'];
	$securityquestion = $_POST['securityquestion'];
	$securityanswer = $_POST['securityanswer'];


	if(!preg_match("/^[a-zA-Z ]*$/", $lastname)){
		$error['lastname'] = 'Invalid Lastname!';
	}
	if(!preg_match("/^[a-zA-Z ]*$/", $firstname)){
		$error['firstname'] = 'Invalid firstname!';
	}
	if(!preg_match("/^[a-zA-Z ]*$/", $middlename)){
		$error['middlename'] = 'Invalid middlename!';
	}
	if(!preg_match("/^[a-zA-Z1-9]*$/", $username)){
		$error['username'] = 'Invalid username!';
	}
	if(strlen($contactnumber) != 11){
		$error['contactnumber'] = 'Invalid contactnumber!';
	}

	if(empty($error)){

		$insertUser = Controller::insertUser([
			'firstname' => $firstname,
			'middlename' => $middlename,
			'lastname' => $lastname,
			'username' => $username,
			'password' => password_hash($password, PASSWORD_DEFAULT),
			'security_question' => $securityquestion,
			'security_answer' => password_hash(strtolower($securityanswer), PASSWORD_DEFAULT),
			'type' => strtolower($type),
			'contactnumber' => $contactnumber,
		]);

		$success = 1;

	}



?>


	<div class="row">

		<div class="col-lg-6">
			<div class="form-floating mb-3">
			  <input type="text" class="form-control" id="floatingPassword" placeholder="Last name" value="<?= $lastname; ?>" required>
			  <label for="floatingPassword">Last name</label>
			  <small class="text-danger"><?= $error['lastname'] ?? '' ?></small>
			</div>
			<div class="form-floating mb-3">
			  <input type="text" class="form-control" id="floatingInput" placeholder="First name" value="<?= $firstname; ?>" required>
			  <label for="floatingInput">First name</label>
			  <small class="text-danger"><?= $error['firstname'] ?? '' ?></small>
			</div>
			<div class="form-floating mb-3">
			  <input type="text" class="form-control" id="floatingPassword" placeholder="Middle name" value="<?= $middlename; ?>" required>
			  <label for="floatingPassword">Middle name</label>
			  <small class="text-danger"><?= $error['middlename'] ?? '' ?></small>
			</div>
			<div class="mb-3">
			  <label>-- TYPE --</label>
			  <br>
			<select class="form-select mb-3 mt-1">
				<option><?= $type; ?></option>
		        <option>Admin</option>
		        <option>Staff</option>
			</select>
			</div>
			<div class="form-floating">  
			  <input type="number" class="form-control" id="floatingPassword" placeholder="Contact number" value="<?= $contactnumber; ?>">
			  <label for="floatingPassword">Contact number</label>
			  <small class="text-danger"><?= $error['contactnumber'] ?? '' ?></small>
			</div>
		</div>


	    <div class="col-lg-6">
	      <div class="form-floating mb-3">
	        <input type="text" class="form-control" id="floatingPassword" placeholder="Username" value="<?= $username; ?>" required>
	        <label for="floatingPassword">Username</label>
	        <small class="text-danger"><?= $error['username'] ?? '' ?></small>
	      </div>
	      <div class="form-floating mb-3">
	        <input type="text" class="form-control" id="floatingInput" placeholder="Password" value="123" disabled>
	        <label for="floatingInput">Default Password</label>
	      </div>
	      
	      <div class="mb-3">
	        <label>Security Question</label>
	        <br>
	      <select class="form-select mb-3 mt-1" disabled>
	        <option>What is your favorite color?</option>
	      </select>
	      </div>

	      <div class="mb-3">
	        <label>Security Answer</label>
	        <br>
	      <select class="form-select mb-3 mt-1" disabled>
	        <option>Red</option>
	      </select>
	      </div>
	    </div>

		</div>

		<script>
			
			<?php if(isset($success)) : ?>
				alert('NEW USER SUCCESSFULLY ADDED!');
				window.location.href = 'admin-maintenance';
			<?php endif; ?>

		</script>