<?php 

require '../../classes/class.model.php';
require '../../classes/class.view.php';
require '../../classes/class.controller.php';

$id = $_POST['id'];

$fetchSingleUser = View::fetchSingleUser([
	'user_id' => $id
]);


?>



<div class="form-floating mb-3">
  <input type="text" class="form-control" id="floatingPassword" placeholder="Last name" value="<?= $fetchSingleUser->lastname; ?>" required>
  <label for="floatingPassword">Last name</label>
</div>
<div class="form-floating mb-3">
  <input type="text" class="form-control" id="floatingInput" placeholder="First name" value="<?= $fetchSingleUser->firstname; ?>" required>
  <label for="floatingInput">First name</label>
</div>
<div class="form-floating mb-3">
  <input type="text" class="form-control" id="floatingPassword" placeholder="Middle name" value="<?= $fetchSingleUser->middlename; ?>" required>
  <label for="floatingPassword">Middle name</label>
</div>




<div class="form-floating mb-3">
  <input type="text" class="form-control" id="floatingPassword" placeholder="Username" value="<?= $fetchSingleUser->username; ?>" required>
  <label for="floatingPassword">Username</label>
</div>

<div class="form-floating">  
  <input type="number" class="form-control" id="floatingPassword" placeholder="Contact number" value="<?= $fetchSingleUser->contactnumber; ?>">
  <label for="floatingPassword">Contact number</label>
</div>
<div class="mb-3">
  <label>-- TYPE --</label>
  <br>
<select class="form-select mb-3 mt-1">
  <option><?= ucfirst($fetchSingleUser->type); ?></option>
  <option>Admin</option>
  <option>Staff</option>
</select>
<input type="hidden" value="<?= $fetchSingleUser->user_id; ?>">
</div>



<script>
	

	$('#editUser').submit((e) => {

		e.preventDefault();

		const lastname = e.target[0].value;
		const firstname = e.target[1].value;
		const middlename = e.target[2].value;
		const username = e.target[3].value;
		const contactnumber = e.target[4].value;
		const type = e.target[5].value;
		const user_id = e.target[6].value;

		 $.ajax({
          url: 'server/user/edit.php',
          method: 'POST',
          data: {
              lastname: lastname, firstname: firstname, middlename: middlename, username: username, contactnumber: contactnumber, type: type, user_id: user_id
          }, success: function(data) {
            $('.editUserForm').html(data);
           }
        });

	});

</script>