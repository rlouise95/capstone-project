<?php 
	
	require '../../classes/class.model.php';
	require '../../classes/class.view.php';
	require '../../classes/class.controller.php';

	$user_id = $_POST['user_id'];


	$user = Controller::deleteUser([
		'user_id' => $user_id
	]);

?>