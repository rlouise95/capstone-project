<?php 


	require '../../classes/class.model.php';
	require '../../classes/class.view.php';
	require '../../classes/class.controller.php';

	$idnumber = $_POST['idnumber'];

	$fetchBorrower = View::fetchSingleBorrower([
		'idnumber' => $idnumber
	]);


?>

<?php if($fetchBorrower) : ?>

<div class="col-md-6">
	<p class="mb-2">Last Name:</p>
	<p class="mb-2">First Name:</p>
	<p class="mb-2">Middle Name:</p>
	<p class="mb-2">Department:</p>
	<p class="mb-2">Contact:</p>
	<p class="mb-2">Type:</p>
</div>
<div class="col-md-6">
	<p class="mb-2"><?= $fetchBorrower->lastname; ?></p>
	<p class="mb-2"><?= $fetchBorrower->firstname; ?></p>
	<p class="mb-2"><?= $fetchBorrower->middlename; ?></p>
	<p class="mb-2"><?= $fetchBorrower->department_name; ?></p>
	<p class="mb-2"><?= $fetchBorrower->contactnumber; ?></p>
	<p class="mb-2"><?= $fetchBorrower->type; ?></p>

	<input type="hidden" name="idnumber" value="<?= $fetchBorrower->idnumber; ?>">

</div>

<?php else : ?>

	<h3 class="text-center my-5">No Borrower Found!</h3>


<?php endif ?>

