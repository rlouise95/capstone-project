<?php 

	require '../../classes/class.model.php';
	require '../../classes/class.view.php';
	require '../../classes/class.controller.php';

	$accession = $_POST['accession'];

	$fetchbook = View::fetchSingleBook([
	    'accession_id' => $accession
	]);

?>


				<div class="row">
		        	<div class="col-md-6">
		        		<p><?= ucfirst($fetchbook->title); ?></p>
		        		<input type="hidden" name="accession" value="<?= $fetchbook->accession_id; ?>">
		        		<input type="hidden" name="title" value="<?= $fetchbook->title; ?>">
		        		<input type="hidden" name="edition" value="<?= $fetchbook->edition; ?>">
		        		<input type="hidden" name="borrowedcopies" value="<?= $fetchbook->borrowedcopies; ?>">
		        		<input type="hidden" name="availablecopies" value="<?= $fetchbook->availablecopies; ?>">
		        	</div>
			        <div class="col-md-6 d-flex justify-content-end">

				        <div class="mb-2 me-2">
				        	<label> Academic Year </label>
				          	<br>
				        	<select class="form-select" name="academicYear">
				        		  <option value="<?= date("Y"); ?>"><?= date("Y"); ?></option>
				        	</select>
				        </div>

				        <div class="mb-2 ms-2">
				        	<label> Semester</label>
				          	<br>
				        	<select class="form-select" name="semester">
				        		<option>1st</option>
				        		<option>2nd</option>
				        	</select>
				        </div>

			        </div>
		    	</div>

	          	<div>
	          		<input style="outline-style: none;" class="border-top-0 border-start-0 border-end-0" type="number" id="searchBorrower" placeholder="ID number">
	          	</div>

	          	<div class="row mt-3 getBorrower">
		          	<h3 class="text-center my-5">No Borrower Found!</h3>
	    	  	</div>



	    	  	<script>
	    	  		
	    	  		$('#searchBorrower').keyup((e) => {

	    	  			const idnumber = $(e.target).val();


	    	  			$.ajax({
	    	  				url: 'server/borrow/borrowerinfo.php',
	    	  				method: 'POST',
	    	  				data: {
	    	  					idnumber: idnumber
	    	  				}, success: function(data){
	    	  					$('.getBorrower').html(data);
	    	  				}
	    	  			});

	    	  		});

	    	  	</script>