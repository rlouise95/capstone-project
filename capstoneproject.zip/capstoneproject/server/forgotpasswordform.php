<?php 


require '../classes/class.model.php';
require '../classes/class.view.php';
require '../classes/class.controller.php';

	$username = $_POST['username'];

	$countUser = View::countUser([
		'username' => $username]
	);

	if($countUser < 1){

		$error['username'] = 'Username not Found!';

	} else {

		$fetchUser = View::fetchUser([
			'username' => $username]
		);

	}

?>

<?php if(isset($countUser) && $countUser > 0) : ?>

<div class="form-floating mb-2">
  <input type="text" class="form-control px-2" id="floatingInput" value="<?= $fetchUser->username; ?>" placeholder="Username" required disabled>
  <label class="px-4" for="floatingInput ">Username</label>
</div>

<div class="mb-2">
  <label>Current Security Question</label>
  <br>
  <select class="form-select mb-2 mt-1" disabled>
    <option><?= $fetchUser->security_question; ?></option>
  </select>
</div>

<div class="form-floating mb-2 ">
  <input type="password" class="form-control" id="floatingPassword" placeholder="Answer" required>
  <label class="px-4" for="floatingPassword">Answer</label>
</div>

<div class="form-floating mb-2">
  <input type="password" class="form-control" id="floatingPassword" placeholder="New Password" required>
  <label class="px-4" for="floatingPassword">New Password</label>
</div>

<div class="form-floating mb-2">
  <input type="password" class="form-control" id="floatingPassword" placeholder="Confirm Password" required>
  <label class="px-4" for="floatingPassword">Confirm Password</label>
</div>

<div class="mb-2">
  <label>Set New Security Question</label>
  <br>
  <select class="form-select mb-3 mt-1">
    <option>What is your mothers maiden name?</option>
    <option>What primary school did you attend?</option>
    <option>What were the last four digits of your childhood telephone number?</option>
    <option>What was the house number and street name you lived in as a child?</option>
    <option>What is your oldest cousin's first and last name?</option>
    <option>What is the name of your favorite childhood friend?</option>
    <option>What was your childhood nickname?</option>  
  </select>
</div>

<div class="form-floating mb-2">
  <input type="password" class="form-control" id="floatingPassword" placeholder="Answer" required>
  <label class="px-4" for="floatingPassword">Answer</label>
</div>

<?php else: ?>

<h3 class="text-center text-dark"><?= $error['username']; ?></h3>

<?php endif; ?>
