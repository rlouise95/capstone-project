<?php 

	require '../../classes/class.model.php';
	require '../../classes/class.view.php';
	require '../../classes/class.controller.php';

	
	$idnumber = $_POST['idnumber'];

	$fetchDepartments = View::fetchDepartments();

	$fetchBorrower = View::fetchSingleBorrower([
		'idnumber' => $idnumber
	]);

?>




<div class="modal-body">
  
	<div class="row">
		<div class="col-lg-12">
			<div class="form-floating mb-3">
			  <input type="number" class="form-control" id="floatingInput"  value="<?= $fetchBorrower->idnumber; ?>" disabled>
			  <input type="hidden" name="idnumber" value="<?= $fetchBorrower->idnumber; ?>">
			  <label for="floatingInput">ID number</label>
			</div>
			<div class="form-floating mb-3">
			  <input type="text" name="lastname" class="form-control" id="floatingPassword"  value="<?= $fetchBorrower->lastname; ?>">
			  <label for="floatingPassword">Last name</label>
			</div>
			<div class="form-floating mb-3">
			  <input type="text" name="firstname" class="form-control" id="floatingInput"  value="<?= $fetchBorrower->firstname; ?>">
			  <label for="floatingInput">First name</label>
			</div>
			<div class="form-floating mb-3">
			  <input type="text" name="middlename" class="form-control" id="floatingPassword"  value="<?= $fetchBorrower->middlename; ?>">
			  <label for="floatingPassword">Middle name</label>
			</div>
			<div class="mb-3">
			  <label>-- SELECT COURSE --</label>
			  <br>
			<select name="department" class="form-select mb-3 mt-1">
				<option value="<?= $fetchBorrower->department_id; ?>"><?= $fetchBorrower->department_name; ?></option>
			  <?php foreach($fetchDepartments as $department) : ?>
			  		<option value="<?= $department->department_id; ?>"><?= $department->department_name; ?></option>
			  <?php endforeach; ?>
			</select>
			</div>
			<div class="form-floating">
			  <input type="number" name="contactnumber" class="form-control" id="floatingPassword"  value="<?= $fetchBorrower->contactnumber; ?>">
			  <label for="floatingPassword">Contact number</label>
			</div>
			<input type="hidden" name="type" value="<?= $fetchBorrower->type; ?>">
		</div>
	</div>


</div>
<div class="modal-footer">
  <button type="submit" name="editborrower" class="btn btn-primary">Update</button>
</div>