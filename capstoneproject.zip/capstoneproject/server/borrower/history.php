<?php 

	require '../../classes/class.model.php';
	require '../../classes/class.view.php';
	require '../../classes/class.controller.php';

	$fetchRules = View::fetchRules(['id' => 1]);

	$idnumber = $_POST['idnumber'];

	$fetchBorrowerHistory = View::fetchBorrowerHistory([
		'idnumber' => $idnumber
	]);


?>


 
      <table class="table text-start table-striped table-hover">
        <thead>
          <tr>
            <th>Accession</th>
            <th>Category</th>
            <th>Title</th>
            <th>Borrowed Date</th>
            <th>Due Date</th>
            <th>Over Due Date</th>
            <th>Fines</th>
            <th>Status</th>
            <th>Options</th>
          </tr>
        </thead>

        <tbody>
        	<?php foreach($fetchBorrowerHistory as $history) : ?>

    		<?php 

    			$today = strtotime(date('Y-m-d')); 

    			$due_date = strtotime($history->due_date); 

    			$sub = $today - $due_date;

    			$days = 60 * 60 * 24;

    			if($today < $due_date){
    				$penalty = 0;
    			} else {
    				$penalty = abs(floor($sub / $days));
    			}

    		?>

	          <tr id="bookReturn">
	            <td><?= $history->accession_id; ?></td>
	            <td><?= $history->category_name; ?></td>
	            <td><?= $history->title; ?></td>
	            <td><?= $history->semester.'Sem / '. $history->borrowed_date; ?></td>
	            <td><?= $history->semester.'Sem / '. $history->due_date; ?></td>
	            <td><?= $penalty.' days'; ?></td>
	            <td><?= $penalty * $fetchRules->overdue_penalty; ?></td>
              <?php if($penalty < 1)  : ?>
              <td><span>Return Only</span>  <span></span></td>
              <?php else : ?>
              <td><span>Return w/ Fines</span> <span></span></td>
              <?php endif; ?>
	            <td>
	              <select class="form-select w-100" id="option">
                  <!-- <option>Return</option> -->
	               <!--  <option>Return w/ fines</option>
                  <option>Return w/ fines & damaged</option> -->
	                <option></option>
                  <option>Damaged</option>
	                <option>Lost</option>
	              </select>
	            </td>
	            <td class="text-center">
	              <button class="btn btn-primary btn-sm clear">
	                Clear 
	              </button>
	            </td>
              <input type="hidden" value="<?= $history->idnumber; ?>">
              <input type="hidden" value="<?= $history->lastname; ?>">
              <input type="hidden" value="<?= $history->type; ?>">
              <input type="hidden" value="<?= $history->borrowedcopies; ?>">
              <input type="hidden" value="<?= $history->availablecopies; ?>">
	          </tr>
	         <?php endforeach; ?>
        </tbody>

      </table>

      <script>

        $('[id="option"]').change((e) => {

          if(e.target.value == ''){
            const newstatus = e.target.parentElement.parentElement.children[7].children[1].innerText = ''+e.target.value;
            e.target.parentElement.parentElement.children[7].children[0].style.display = 'inline-block';
          } else {  
            const newstatus = e.target.parentElement.parentElement.children[7].children[1].innerText = ' w/ '+e.target.value;
            e.target.parentElement.parentElement.children[7].children[0].style.display = 'inline-block';
          }

          if(e.target.value == 'Lost'){
            const newstatus = e.target.parentElement.parentElement.children[7].children[1].innerText = e.target.value;
            e.target.parentElement.parentElement.children[7].children[0].style.display = 'none';
          }


          $.ajax({
            url: 'server/borrower/computedfines.php',
            method: 'POST',
            data: {
              days: e.target.parentElement.parentElement.children[5].innerText, option: e.target.value
            }, success: function(data) {
              e.target.parentElement.parentElement.children[6].innerText = data;
            }
          });

        });

      	
      	$('[id="bookReturn"]').click((e) => {


      		const accession = e.currentTarget.children[0].innerText;
      		const category_name = e.currentTarget.children[1].innerText;
      		const title = e.currentTarget.children[2].innerText;
      		const borrowed_date = e.currentTarget.children[3].innerText;
      		const due_date = e.currentTarget.children[4].innerText;
      		const overdue_date = e.currentTarget.children[5].innerText;
      		const fines = e.currentTarget.children[6].innerText;
          const bookstatus = e.currentTarget.children[7].innerText;
      		// const optionstatus = e.currentTarget.children[8].children[0].value;

          
          const idnumber = e.currentTarget.children[10].value;
          const lastname = e.currentTarget.children[11].value;
          const type = e.currentTarget.children[12].value;
          const borrowedcopies = e.currentTarget.children[13].value;
          const availablecopies = e.currentTarget.children[14].value;




      		if(e.target.classList.contains('clear')){

            if(bookstatus != 'Lost'){

              if(confirm('Are you sure you want to return this book?')){

                  $.ajax({
                    url: 'server/return/add.php',
                    method: 'POST',
                    data: {
                      accession: accession, category_name: category_name, title: title, borrowed_date: borrowed_date, due_date: due_date, overdue_date: overdue_date, fines: fines, bookstatus: bookstatus, idnumber: idnumber, lastname: lastname, type: type, borrowedcopies: borrowedcopies, availablecopies: availablecopies
                    }, success: function(data) {
                      window.location.reload();
                    }
                  });

               }

            } else {


              if(confirm('The borrower needs to pay for losing the book!')){

                  $.ajax({
                    url: 'server/return/add.php',
                    method: 'POST',
                    data: {
                      accession: accession, category_name: category_name, title: title, borrowed_date: borrowed_date, due_date: due_date, overdue_date: overdue_date, fines: fines, bookstatus: bookstatus, idnumber: idnumber, lastname: lastname, type: type, borrowedcopies: borrowedcopies, availablecopies: availablecopies
                    }, success: function(data) {
                      window.location.reload();
                    }
                  });

               }


            }
      			
      		}
      

      	});

      </script>