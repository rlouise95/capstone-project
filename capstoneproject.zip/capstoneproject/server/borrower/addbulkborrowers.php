<?php 


require '../../classes/class.model.php';
require '../../classes/class.view.php';
require '../../classes/class.controller.php';

include '../../vendor/autoload.php';

$fetchDepartments = View::fetchDepartments();


if(isset($_FILES['file-0']) && $_FILES['file-0']['name'] != ''){


	 $excelFile = pathinfo($_FILES['file-0']['name']);
	 $getExtension = $excelFile['extension'];

		if(in_array($getExtension, array('xls', 'xlsx'))){
		
			$fileName = time() . '.' . $getExtension;
			move_uploaded_file($_FILES['file-0']['tmp_name'], $fileName);
		    $fileType = \PhpOffice\PhpSpreadsheet\IOFactory::identify($fileName);
		    $reader = \PhpOffice\PhpSpreadsheet\IOFactory::createReader($fileType);

		    $spreadsheet = $reader->load($fileName);

		    unlink($fileName);

		     $data = $spreadsheet->getActiveSheet()->toArray();


		     foreach($data as $row) {


		     	foreach ($fetchDepartments as $department) {
		     		if($department->department_name == $row[4]){
		     			$GLOBALS['department_id'] = $department->department_id;
		     		}
		     	}


			     $insertBulkBorrowers = Controller::insertBulkBorrowers([
			     	'idnumber' => $row[0],
			     	'firstname' => ucwords($row[1]),
			     	'middlename' => ucwords($row[2]),
			     	'lastname' => ucwords($row[3]),
			     	'department_id' => $GLOBALS['department_id'],
			     	'contactnumber' => '0'.$row[5],
			     	'type' => ucwords($row[6])
			     ]);

		     }

		     $message = 'Import Successfully!';
			

		} else {

			$message = 'Invalid File Format!';
		}

} else {
	$message = 'Please Choose a File!';
}

echo $message;


?>
