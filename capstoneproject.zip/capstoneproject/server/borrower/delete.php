<?php 
	
	require '../../classes/class.model.php';
	require '../../classes/class.view.php';
	require '../../classes/class.controller.php';

	$idnumber = $_POST['idnumber'];


	$borrower = Controller::deleteBorrower([
		'idnumber' => $idnumber
	]);

?>