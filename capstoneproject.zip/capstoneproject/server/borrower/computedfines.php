<?php 

	require '../../classes/class.model.php';
	require '../../classes/class.view.php';
	require '../../classes/class.controller.php';

	$fetchRules = View::fetchRules(['id' => 1]);

	$days = $_POST['days'];
	$option = $_POST['option'];

	$getnumberdays = explode(' ', $days);


	switch ($option) {
		case 'Damaged':
			if ($getnumberdays[0] != 0){
				echo $getnumberdays[0] * $fetchRules->overdue_penalty + $fetchRules->damaged_penalty;
			} else {
				echo $fetchRules->damaged_penalty;
			}
			break;

		case 'Lost':
		echo $fetchRules->lost_penalty;
		break;
		default:
			echo $getnumberdays[0] * $fetchRules->overdue_penalty;
			break;
	}