<?php 

	session_start();

	require '../../classes/class.model.php';
	require '../../classes/class.view.php';
	require '../../classes/class.controller.php';

	$fetchRules = View::fetchRules(['id' => 1]);


	$accession = $_POST['accession'];
	$category_name = $_POST['category_name'];
	$title = $_POST['title'];
	$date_borrowed = $_POST['borrowed_date'];
	$due_date = $_POST['due_date'];
	$exceed_days = $_POST['overdue_date'];
	$fines = $_POST['fines'];
	$bookstatus = $_POST['bookstatus'];
	
	$borrower_idnumber = $_POST['idnumber'];
	$borrower_lastname = $_POST['lastname'];
	$borrower_type = $_POST['type'];

	$borrowedcopies = $_POST['borrowedcopies'];
	$availablecopies = $_POST['availablecopies'];

	$reciever_lastname = $_SESSION['lastname'];
	$reciever_type = $_SESSION['type'];

	$getSemester = explode('/', $due_date);


	switch ($bookstatus) {
		

		case 'Return w/ Damaged':

			$insertBookReturn = Controller::insertBookReturn([
				'accession_id' => $accession,
				'category_name' => $category_name,
				'title' => $title,
				'borrower_idnumber' => $borrower_idnumber,
				'borrower_lastname' => $borrower_lastname,
				'borrower_type' => $borrower_type,
				'reciever_lastname' => $reciever_lastname,
				'reciever_type' => $reciever_type,
				'date_borrowed' => $date_borrowed,
				'date_returned' => $getSemester[0].' / '.date('Y-m-d'),
				'exceed_days' => $exceed_days,
				'return_status' => $bookstatus,
				'fines' => $fines,
			]);


			$UpdateBook = Controller::UpdateBook([
				'borrowedcopies' => (int)$borrowedcopies - 1,
				'availablecopies' => (int)$availablecopies + 1
			], ['accession_id' => $accession]);


			$deleteBorrowedBook = Controller::deleteBorrowedBook([
				'idnumber' => $borrower_idnumber,
				'accession_id' => $accession
			]);



			break;

			case 'Return w/ Fines':

				$insertBookReturn = Controller::insertBookReturn([
					'accession_id' => $accession,
					'category_name' => $category_name,
					'title' => $title,
					'borrower_idnumber' => $borrower_idnumber,
					'borrower_lastname' => $borrower_lastname,
					'borrower_type' => $borrower_type,
					'reciever_lastname' => $reciever_lastname,
					'reciever_type' => $reciever_type,
					'date_borrowed' => $date_borrowed,
					'date_returned' => $getSemester[0].' / '.date('Y-m-d'),
					'exceed_days' => $exceed_days,
					'return_status' => $bookstatus,
					'fines' => $fines,
				]);


				$UpdateBook = Controller::UpdateBook([
					'borrowedcopies' => (int)$borrowedcopies - 1,
					'availablecopies' => (int)$availablecopies + 1
				], ['accession_id' => $accession]);


				$deleteBorrowedBook = Controller::deleteBorrowedBook([
					'idnumber' => $borrower_idnumber,
					'accession_id' => $accession
				]);



				break;

				case 'Return w/ Fines w/ Damaged':

					$insertBookReturn = Controller::insertBookReturn([
						'accession_id' => $accession,
						'category_name' => $category_name,
						'title' => $title,
						'borrower_idnumber' => $borrower_idnumber,
						'borrower_lastname' => $borrower_lastname,
						'borrower_type' => $borrower_type,
						'reciever_lastname' => $reciever_lastname,
						'reciever_type' => $reciever_type,
						'date_borrowed' => $date_borrowed,
						'date_returned' => $getSemester[0].' / '.date('Y-m-d'),
						'exceed_days' => $exceed_days,
						'return_status' => $bookstatus,
						'fines' => $fines,
					]);


					$UpdateBook = Controller::UpdateBook([
						'borrowedcopies' => (int)$borrowedcopies - 1,
						'availablecopies' => (int)$availablecopies + 1
					], ['accession_id' => $accession]);


					$deleteBorrowedBook = Controller::deleteBorrowedBook([
						'idnumber' => $borrower_idnumber,
						'accession_id' => $accession
					]);



					break;

		case 'Lost':
			
			$insertBookReturn = Controller::insertBookReturn([
				'accession_id' => $accession,
				'category_name' => $category_name,
				'title' => $title,
				'borrower_idnumber' => $borrower_idnumber,
				'borrower_lastname' => $borrower_lastname,
				'borrower_type' => $borrower_type,
				'reciever_lastname' => $reciever_lastname,
				'reciever_type' => $reciever_type,
				'date_borrowed' => $date_borrowed,
				'date_returned' => $getSemester[0].' / '.date('Y-m-d'),
				'exceed_days' => $exceed_days,
				'return_status' => $bookstatus,
				'fines' => $fines,
			]);


			$UpdateBook = Controller::UpdateBook([
				'borrowedcopies' => (int)$borrowedcopies - 1,
				'availablecopies' => (int)$availablecopies + 1
			], ['accession_id' => $accession]);



			$deleteBorrowedBook = Controller::deleteBorrowedBook([
				'idnumber' => $borrower_idnumber,
				'accession_id' => $accession
			]);


			break;
		
		default:
			
			$insertBookReturn = Controller::insertBookReturn([
				'accession_id' => $accession,
				'category_name' => $category_name,
				'title' => $title,
				'borrower_idnumber' => $borrower_idnumber,
				'borrower_lastname' => $borrower_lastname,
				'borrower_type' => $borrower_type,
				'reciever_lastname' => $reciever_lastname,
				'reciever_type' => $reciever_type,
				'date_borrowed' => $date_borrowed,
				'date_returned' => $getSemester[0].' / '.date('Y-m-d'),
				'exceed_days' => $exceed_days,
				'return_status' => $bookstatus,
				'fines' => $fines,
			]);


			$UpdateBook = Controller::UpdateBook([
				'borrowedcopies' => (int)$borrowedcopies - 1,
				'availablecopies' => (int)$availablecopies + 1
			], ['accession_id' => $accession]);



			$deleteBorrowedBook = Controller::deleteBorrowedBook([
				'idnumber' => $borrower_idnumber,
				'accession_id' => $accession
			]);
			


			break;
	}

?>