<?php 


require '../classes/class.model.php';
require '../classes/class.view.php';
require '../classes/class.controller.php';

	$username = $_POST['username'];
  $answer = $_POST['answer'];
  $newpassword = htmlspecialchars($_POST['newpassword']);
  $confirmpassword = htmlspecialchars($_POST['confirmpassword']);
  $newquestion = $_POST['newquestion'];
  $newanswer = htmlspecialchars($_POST['newanswer']);


  $fetchUser = View::fetchUser([
    'username' => $username]
  );

  $getCurrentAnswer = password_verify($answer, $fetchUser->security_answer);


  if($getCurrentAnswer){

    if($newpassword !== $confirmpassword){

       $error['password'] = 'Password not matched!';

    } else {

        $setNewSecurity = Controller::setNewSecurity([
          'password' => password_hash($newpassword, PASSWORD_DEFAULT),
          'security_question' => $newquestion,
          'security_answer' =>  password_hash($newanswer, PASSWORD_DEFAULT)
        ], ['user_id' => $fetchUser->user_id]);

        $success = 1;

    }

  } else {

    $error['answer'] = 'Wrong Answer!';

  }


?>

<div class="form-floating mb-2">
  <input type="text" class="form-control px-2" id="floatingInput" value="<?= $fetchUser->username; ?>" placeholder="Username" required disabled>
  <label class="px-4" for="floatingInput ">Username</label>
</div>

<div class="mb-2">
  <label>Current Security Question</label>
  <br>
  <select class="form-select mb-2 mt-1" disabled>
    <option><?= $fetchUser->security_question; ?></option>
  </select>
</div>

<div class="form-floating mb-2 ">
  <input type="password" class="form-control" id="floatingPassword" placeholder="Answer" required value="<?= $answer; ?>">
  <label class="px-4" for="floatingPassword">Answer</label>
  <small class="text-danger"><?= $error['answer'] ?? ''; ?></small>
</div>

<div class="form-floating mb-2">
  <input type="password" class="form-control" id="floatingPassword" placeholder="New Password" required value="<?= $newpassword; ?>">
  <label class="px-4" for="floatingPassword">New Password</label>
  <small class="text-danger"><?= $error['password'] ?? ''; ?></small>
</div>

<div class="form-floating mb-2">
  <input type="password" class="form-control" id="floatingPassword" placeholder="Confirm Password" required value="<?= $confirmpassword; ?>">
  <label class="px-4" for="floatingPassword">Confirm Password</label>
  <small class="text-danger"><?= $error['password'] ?? ''; ?></small>
</div>

<div class="mb-2">
  <label>Set New Security Question</label>
  <br>
  <select class="form-select mb-3 mt-1">
    <option><?= $newquestion; ?></option>
    <option>What is your mothers maiden name?</option>
    <option>What primary school did you attend?</option>
    <option>What were the last four digits of your childhood telephone number?</option>
    <option>What was the house number and street name you lived in as a child?</option>
    <option>What is your oldest cousin's first and last name?</option>
    <option>What is the name of your favorite childhood friend?</option>
    <option>What was your childhood nickname?</option>  
  </select>
</div>

<div class="form-floating mb-2">
  <input type="password" class="form-control" id="floatingPassword" placeholder="Answer" required value="<?= $newanswer; ?>">
  <label class="px-4" for="floatingPassword">Answer</label>
</div>


<script>
<?php if(isset($success)) : ?>
  alert('Changes Successfully!');
  window.location.href = 'login';
<?php endif; ?>
</script>


