<?php 
	
	require '../../classes/class.model.php';
	require '../../classes/class.view.php';
	require '../../classes/class.controller.php';

	$id = $_POST['id'];


	$department = View::fetchSingleDepartment([
		'department_id' => $id
	]);

?>

<input class="form-control" type="text" name="departmentName" value="<?= $department->department_name; ?>">
<input class="form-control" type="hidden" name="departmentId" value="<?= $department->department_id; ?>">

