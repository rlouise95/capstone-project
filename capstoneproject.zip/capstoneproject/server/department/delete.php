<?php 
	
	require '../../classes/class.model.php';
	require '../../classes/class.view.php';
	require '../../classes/class.controller.php';

	$id = $_POST['id'];


	$department = Controller::deleteDepartment([
		'department_id' => $id
	]);

?>




