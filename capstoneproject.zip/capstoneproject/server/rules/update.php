<?php 

	require '../../classes/class.model.php';
	require '../../classes/class.view.php';
	require '../../classes/class.controller.php';


	if(isset($_POST['save'])){

		$allowed_books = $_POST['allowed_books'];
		$allowed_days = $_POST['allowed_days'];
		$overdue_penalty = $_POST['overdue_penalty'];
		$damaged_penalty = $_POST['damaged_penalty'];
		$lost_penalty = $_POST['lost_penalty'];

		$updateRules = Controller::updateRules([
			'allowed_books' => $allowed_books,
			'allowed_days' => $allowed_days,
			'overdue_penalty' => $overdue_penalty,
			'damaged_penalty' => $damaged_penalty,
			'lost_penalty' => $lost_penalty
		], ['id' => 1]);

		header('Location: ../../admin-maintenance');

	}



	$fetchRules = View::fetchRules(['id' => 1]);



?>





	<form method="POST" action="<?= $_SERVER['PHP_SELF']; ?>" class="w-50 m-auto p-2">
	  <div class="mb-1">
	    <label class="form-label">Number of books allowed to borrow</label>
	    <input type="number" class="form-control" name="allowed_books" value="<?= $fetchRules->allowed_books; ?>" required>
	  </div>

	  <div class="mb-1">
	    <label  class="form-label">Number of days allowed</label>
	    <input type="number" class="form-control" name="allowed_days" value="<?= $fetchRules->allowed_days; ?>" required>
	  </div>

	  <div class="mb-1">
	    <label class="form-label">Overdue Date Penalty</label>
	    <input type="number" class="form-control" name="overdue_penalty" value="<?= $fetchRules->overdue_penalty; ?>" required>
	  </div>
	  <div class="mb-1">
	    <label class="form-label">Book Damaged Penalty</label>
	    <input type="number" class="form-control" name="damaged_penalty" value="<?= $fetchRules->damaged_penalty; ?>" required>
	  </div>
	  <div class="mb-1">
	    <label class="form-label">Book Lost Penalty</label>
	    <input type="number" class="form-control" name="lost_penalty" value="<?= $fetchRules->lost_penalty; ?>" required>
	  </div>
	  <button type="submit" name="save" class="btn btn-primary mt-1 w-100">Save</button>
	</form>
