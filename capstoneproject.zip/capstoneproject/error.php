<!DOCTYPE html>
<html>
<head>
	<title>ERROR</title>
	<link rel="preconnect" href="https://fonts.gstatic.com">

	<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@1,700&display=swap" rel="stylesheet">
	<style>
		*{
			padding: 0;
			margin: 0;
			box-shadow: border-box;
		}
		body{
			display: flex;
			justify-content: center;
			align-items: center;
			height: 100vh;
			width: 100%;
			overflow:hidden;
		}
		.container{
			display: flex;
			width: 100%;
			flex-direction: column;
			justify-content: center;
			align-items: center;
			font-family: 'Roboto', sans-serif;	
			background-color: royalblue;
			color:#fff;
		}
		.number{
			display: flex;
			width: 100%;
			justify-content: center;
		}
		.number h2{
			font-size: 250px;
		}
		.word{
			font-size: 100px;
			opacity: 0;
			
		}
		div
	</style>
</head>
<body>
	<div class="container">
		<div class="number">
			<h2>4</h2>
			<h2>0</h2>
			<h2>4</h2>
		</div>
		<h2 class="word">Page Not Found</h2>
	</div>
	<script src="js/gsap/offline-gsap.min.js"></script>
	<script>
		const error = gsap.timeline();

		error.fromTo('.container',{x:'100%'},{x:'0%',duration:'1'});
		error.fromTo('.number h2',{opacity:'0',x:'100%'},{opacity:'1',x:'0%',stagger:'0.3',ease:'elastic',duration:'0.5'});
		error.to('.container',{height:'100%',duration:'0.3'});
		error.to('.word',{opacity:'1.3'});

	
	</script>
</body>
</html>