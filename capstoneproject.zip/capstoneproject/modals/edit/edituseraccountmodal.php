<div class="modal fade" id="updateUserAccountModal">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Manage Account</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <form id="submitNewPassword" class="w-100">

      <div class="modal-body forgotPassword row">
        

           

      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-primary">SUBMIT</button>
      </div>

      </form>
    </div>
  </div>
</div>