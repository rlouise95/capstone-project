<div class="modal fade" id="updateDepartmentModal">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Update Department</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form method="POST" action="admin-maintenance">
      <div class="modal-body department-body">
      
      </div>
      <div class="modal-footer">
        <input type="submit" class="btn btn-primary" value="Update" name="updateDepartment">
      </div>
       </form>  
    </div>
  </div>
</div>