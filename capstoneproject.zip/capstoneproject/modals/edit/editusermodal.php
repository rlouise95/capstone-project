<div class="modal fade" id="updateUserFormModal">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Update user</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <form id="editUser">


        <div class="modal-body editUserForm">
          

        </div>

        
        <div class="modal-footer">
          <button type="submit" class="btn btn-primary">UPDATE</button>
        </div>

      </form>
    </div>
  </div>
</div>