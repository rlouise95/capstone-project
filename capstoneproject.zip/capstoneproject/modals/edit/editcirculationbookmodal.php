<div class="modal fade" id="editCirculationView">
	<div class="modal-dialog modal-dialog-scrollable modal-lg">
	  <div class="modal-content">
	    <div class="modal-header">
	      <h5 class="modal-title" id="exampleModalLabel">Edit book</h5>
	      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
	    </div>

	<form id="editBook">
	    <div class="row modal-body editCirculationBookModal">

	    	
	      
	    </div>
	    <div class="modal-footer">
	      <input type="submit" class="btn btn-primary" value="UPDATE">
	    </div>
	</form>

	  </div>
	</div>
</div>