<div class="modal fade" id="reservedBookCopyModal">
	<div class="modal-dialog modal-lg">
	  <div class="modal-content">
	    <div class="modal-header">
	      <h5 class="modal-title">Add book copy</h5>
	      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
	    </div>

		<form id="addBookCopy">
		    <div class="row modal-body book-copy text-start">
		      
			

		    </div>
		    <div class="modal-footer">
		      <input type="submit" class="btn btn-primary" value="ADD COPY">
		    </div>
		</form>
	  </div>
	</div>
	</div>