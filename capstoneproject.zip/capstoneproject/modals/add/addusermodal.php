<div class="modal fade" id="addUserFormModal">
  <div class="modal-dialog modal-dialog-scrollable modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Add new user</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <form id="addUser">

      <div class="modal-body user-body">
        
      	<div class="row">

      		<div class="col-lg-6">
      			<div class="form-floating mb-3">
      			  <input type="text" class="form-control" id="floatingPassword" placeholder="Last name" required>
      			  <label for="floatingPassword">Last name</label>
      			</div>
      			<div class="form-floating mb-3">
      			  <input type="text" class="form-control" id="floatingInput" placeholder="First name" required>
      			  <label for="floatingInput">First name</label>
      			</div>
      			<div class="form-floating mb-3">
      			  <input type="text" class="form-control" id="floatingPassword" placeholder="Middle name" required>
      			  <label for="floatingPassword">Middle name</label>
      			</div>
      			<div class="mb-3">
      			  <label>-- TYPE --</label>
      			  <br>
      			<select class="form-select mb-3 mt-1">
              <option>Staff</option>
      			</select>
      			</div>
      			<div class="form-floating">  
      			  <input type="number" class="form-control" id="floatingPassword" placeholder="Contact number">
      			  <label for="floatingPassword">Contact number</label>
      			</div>
      		</div>


          <div class="col-lg-6">
            <div class="form-floating mb-3">
              <input type="text" class="form-control" id="floatingPassword" placeholder="Username" required>
              <label for="floatingPassword">Username</label>
            </div>
            <div class="form-floating mb-3">
              <input type="text" class="form-control" id="floatingInput" placeholder="Password" value="123" disabled>
              <label for="floatingInput">Default Password</label>
            </div>
            
            <div class="mb-3">
              <label>Security Question</label>
              <br>
            <select class="form-select mb-3 mt-1" disabled>
              <option>What is your favorite color?</option>
            </select>
            </div>

            <div class="mb-3">
              <label>Security Answer</label>
              <br>
            <select class="form-select mb-3 mt-1" disabled>
              <option>Red</option>
            </select>
            </div>
          </div>

      	</div>


      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-primary">ADD</button>
      </div>

      </form>
    </div>
  </div>
</div>