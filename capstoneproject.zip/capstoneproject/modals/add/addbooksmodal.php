<div class="modal fade" id="addBookModal">
	<div class="modal-dialog modal-lg">
	  <div class="modal-content">
	    <div class="modal-header">
	      <h5 class="modal-title">Add new book</h5>
	      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
	    </div>

	<form id="addBook">
	    <div class="row modal-body book-body">
	      
		<div class="col-lg-6">
			<div class="form-floating mb-2">
				<input type="number" class="form-control accession" id="floatingInput" required autocomplete="off">
				<label for="floatingInput">Accession number</label>
			</div>
			<div class="form-floating mb-2">
				<input type="number" class="form-control ddc" id="floatingPassword" required autocomplete="off">
				<label for="floatingPassword">DDC</label>
			</div>
			<div class="form-floating mb-2">
				<input type="text" class="form-control author" id="floatingPassword" required autocomplete="off">
				<label for="floatingPassword">Author</label>
			</div>
			<div class="form-floating mb-2">
				<input type="text" class="form-control title" id="floatingPassword" required autocomplete="off">
				<label for="floatingPassword">Title</label>
			</div>
			<div class="form-floating mb-2">
				<input type="number" class="form-control edition" id="floatingPassword" required autocomplete="off">
				<label for="floatingPassword">Edition number</label>
			</div>
			<div class="form-floating mb-2">
				<input type="text" class="form-control placeofpublication" id="floatingPassword" required autocomplete="off">
				<label for="floatingPassword">Place of publication</label>
			</div>	
			<!-- <div class="form-floating mb-2">
				<input type="number" class="form-control copies" id="floatingPassword" required autocomplete="off">
				<label for="floatingPassword">Total copies</label>
			</div>	 -->			  	    
		</div>
		<div class="col-lg-6">
			<div class="mb-3">
			  <label> PUBLISHER </label>
			  <br>
			  <select class="form-select mb-3 mt-1 publisher">
				  <?php foreach($fetchPublishers as $publisher) : ?>
				  	<option value="<?= $publisher->publisher_id; ?>"><?= $publisher->publisher_name; ?></option>
				  <?php endforeach; ?>
				</select>
			</div>
			<div class="mb-3">
			  <label> CATEGORY </label>
			  <br>
			  <select class="form-select mb-3 mt-1 category">
				  <?php foreach($fetchCategories as $category) : ?>
				  	<option value="<?= $category->category_id; ?>"><?= $category->category_name; ?></option>
				  <?php endforeach; ?>
				</select>
			</div>
			<div class="mb-2">
				<label> COPYRIGHT DATE </label>
			  	<br>
				<select class="form-select copyrightdate" required>
				 <?php for ($year = (int)date('Y'); 1900 <= $year; $year--): ?>
					   <option value="<?=$year;?>"><?=$year;?></option>
				 <?php endfor; ?>
				</select>
			</div>
			<div class="mb-3">
			  <label> BOOK STATUS </label>
			  <br>
			  <select class="form-select mb-3 mt-1 status">
				  <option>On-stock</option>
				  <option>For purchased</option>
				</select>
			</div>
			<div class="mb-3">
			  <label> BOOK TYPE </label>
			  <br>
			  <select class="form-select mb-3 mt-1 type">
				  <option>Circulation</option>
				  <option>Reserved</option>
				</select>
			</div>
			<div class="form-group py-1">
				<label> BOOK IMAGE </label>
				<input type="file"  class="form-control mt-1 image" required>
			</div>
		</div>

	    </div>
	    <div class="modal-footer">
	      <input type="submit" class="btn btn-primary" value="ADD">
	    </div>
		</form>
	  </div>
	</div>
	</div>