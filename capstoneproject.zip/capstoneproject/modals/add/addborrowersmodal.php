<div class="modal fade" id="addBorrowersModal">
	<div class="modal-dialog modal-md">
	  <div class="modal-content">
	    <div class="modal-header">
	      <h5 class="modal-title">Book Borrow</h5>
	      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
	    </div>

	    <form method="POST" action="admin-bookavailable">
	        <div class="modal-body borrow-body">

	        	
	    		
	        </div>
	        <div class="modal-footer">
	          <input type="submit" class="btn btn-primary" name="borrowBook" value="BORROW">
	        </div>
	    </form>
	
	  </div>
	</div>
	</div>