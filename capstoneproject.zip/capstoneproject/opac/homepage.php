<?php 


	$fetchCategories = View::fetchCategories();

	

?>
<!DOCTYPE html>
<html>
<head>
	<title>OPAC</title>
	<link rel="stylesheet" type="text/css" href="css/style2.css">
	<link href="css/bootstrap/bootstrap2.min.css" rel="stylesheet">
	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=Lobster&family=Noto+Serif+JP&family=Roboto&display=swap" rel="stylesheet">
</head>
<body>
	<div class="wrapper">
		<main>
			<nav>

				<div class="logo">
					<img id="img-logo" src="images/123.gif">
				</div>

				<div class="search-box">
					<div class="search-category">
						<select class="key-category" id="select-category">

							<option>All</option>


							<?php foreach($fetchCategories as $category) : ?>

							<?php 
								$countBookCategory = View::countBookCategory([
									'category_name' => $category->category_name,
									'broadcast' => 1
								]);
							?>

								<?php if($countBookCategory > 0) : ?>

								<option value="<?= $category->category_id; ?>"><?= ucfirst($category->category_name); ?></option>

								<?php endif; ?>

							<?php endforeach; ?>


						</select>
					</div>

					<div class="search-book">
						<select class="key-book" id="select-key">
							<option value="books.title">Title</option>
							<option value="books.author">Author</option>
							<option>Publisher</option>
							<option value="books.ddc">DDC</option>
						</select>
						<input type="text" id="search-input" placeholder="Search">
					</div>
				</div>
				

				<div class="tab">
					<ul class="nav nav-tabs" id="myTab" role="tablist">
					  <li class="nav-item" role="presentation">
					    <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#circulation" type="button" role="tab" aria-selected="true">Circulation</button>
					  </li>
					  <li class="nav-item" role="presentation">
					    <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#reserved" type="button" role="tab" aria-selected="false">Reserved</button>
					  </li>
					</ul>
				</div>

			</nav>



			<div class="tab-content" id="myTabContent">
			 
				<div class="shelves tab-pane fade show active" role="tabpanel" id="circulation">	
					
				</div>


				<div class="shelves tab-pane fade show active" role="tabpanel" id="reserved">

				</div>

			</div>


		</main>
	</div>

	<div class="loader">
		<img class="loader-img" src="images/learn.gif">
		<div class="intro-text">
			<h3 class="letter"><span>W</span></h3>
			<h3 class="letter"><span>E</span></h3>
			<h3 class="letter"><span>L</span></h3>
			<h3 class="letter"><span>C</span></h3>
			<h3 class="letter"><span>O</span></h3>
			<h3 class="letter"><span>M</span></h3>
			<h3 class="letter"><span>E</span></h3>
			<h3 class="letter"><span>.</span></h3>
			<h3 class="letter"><span>.</span></h3>
			<h3 class="letter"><span>.</span></h3>
			<h3 class="letter"><span>!</span></h3>
		</div>
	</div>
	<div class="slider">
		
	</div>

	<script src="js/jquery/offline-jquery.js"></script>
	<script src="js/bootstrap/bootstrap.bundle.min.js"></script>
	<script src="js/gsap/offline-gsap.min.js"></script>
	<script src="js/index2.js"></script>
</body>
</html>