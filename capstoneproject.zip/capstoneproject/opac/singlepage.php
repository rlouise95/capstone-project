<?php 

	$accession = $_GET['id'];

	$fetchSingleBook = View::fetchSingleBook([
		'accession_id' => $accession
	]);

	?>


<!DOCTYPE html>
<html>
<head>
	<title>Single Page</title>
	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=Lobster&family=Noto+Serif+JP&family=Roboto&display=swap" rel="stylesheet">
	<!-- CSS only -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="css/style2.css">
</head>
<body id="sp-body">
	
		<div class="sp-wrapper">
			<div class="content">

				<div class="display sp-cover-wrapper">
					<img class="sp-cover mb-2" src="images/book/<?= $fetchSingleBook->image; ?>">
					<div class=" accss d-flex flex-column text-center justify-content-center">
						<p class="mb-0 ms-2"><?= $fetchSingleBook->accession_id; ?></p>
						<label>Accession number </label>
						
					</div>
				</div>

				<div class="display book-infos">
					<div class="info">
						<label>Category: </label>
						<p><?= $fetchSingleBook->category_name; ?></p>
					</div>
					<div class="info">
						<label>DDC: </label>
						<p><?= $fetchSingleBook->ddc; ?></p>
					</div>
					<div class="info">
						<label>Author: </label>
						<p><?= $fetchSingleBook->author; ?></p>
					</div>
					<div class="info">
						<label>Title: </label>
						<p><?= $fetchSingleBook->title; ?></p>
					</div>
					<div class="info">
						<label>Edition: </label>
						<p>5<?= $fetchSingleBook->edition; ?></p>
					</div>
					<div class="info">
						<label>Place Publication: </label>
						<p><?= $fetchSingleBook->placeofpublication; ?></p>
					</div>
					<div class="info">
						<label>Publisher: </label>
						<p><?= $fetchSingleBook->publisher_name; ?></p>
					</div>
					<div class="info">
						<label>Copyright date: </label>
						<p><?= $fetchSingleBook->copyrightdate; ?></p>
					</div>
					
					
					<div class="info">
						<label>Date added:</label>
						<p><?= $fetchSingleBook->date_added; ?></p>
					</div>
				</div>
				<div class="type-text bg-danger text-light">
					<h3 class="block"><?= ucfirst($fetchSingleBook->type); ?></h3>
				</div>

				<?php if($fetchSingleBook->status == 'On-stock') : ?>

					<?php if($fetchSingleBook->availablecopies != 0) : ?>
						<button type="button" id="badge" class="btn display">
						Available <span class="badge bg-dark"><span>&#10003;</span></span>
						</button>
					<?php else : ?>
						<button type="button" id="badge" class="btn display">
						   Already Borrowed <span class="badge bg-dark"><span>&#10005;</span></span>
						</button>
					<?php endif; ?>

				<?php else : ?>

						<button type="button" id="badge" class="btn display">
						This Book is For purchased <span class="badge bg-dark"><span>&#10005;</span></span>
						</button>

				<?php endif; ?>

				
			</div>	
		</div>

		<div class="bg-slider">
			
		</div>
		

	<script src="js/jquery/offline-jquery.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.6.1/gsap.min.js" integrity="sha512-cdV6j5t5o24hkSciVrb8Ki6FveC2SgwGfLE31+ZQRHAeSRxYhAQskLkq3dLm8ZcWe1N3vBOEYmmbhzf7NTtFFQ==" crossorigin="anonymous"></script>
	<script src="js/index2.js"></script>

</body>
</html>