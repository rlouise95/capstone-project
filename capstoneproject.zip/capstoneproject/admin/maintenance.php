	<?php 

	if($_SESSION['type'] != 'admin'){
		header("Location: admin-student");
	}

	$fetchRules = View::fetchRules(['id' => 1]);

	
	// ADD CATEGORY FORM
	if(isset($_POST['addCategory'])){

		$categoryName = $_POST['categoryName'];

		$countCategory = View::countCategory([
			'category_name' => $categoryName
		]);


		if($countCategory > 0) {

			$categoryExist = 1;

		} else {

			$categoryAdded = 'added';

			$insertCategory = Controller::insertCategory([
				'category_name' => $categoryName
			]);

		}

	}

	// UPDATE CATEGORY FORM
	if(isset($_POST['updateCategory'])){

		$categoryId = $_POST['categoryId'];
		$categoryName = $_POST['categoryName'];

		$countCategory = View::countCategory([
			'category_name' => $categoryName
		]);


		if($countCategory > 0) {

			$categoryExist = 1;

		} else {

			$updateCategory = Controller::updateCategory([
				'category_name' => $categoryName,
			], ['category_id' => $categoryId]);

			$categoryUpdated = 'updated';
		}

	}
	// END UPDATE CATEGORY FORM


	// ADD PUBLISHER FORM
	if(isset($_POST['addPublisher'])){

		$publisherName = $_POST['publisherName'];

		$countPublisher = View::countPublisher([
			'publisher_name' => $publisherName
		]);


		if($countPublisher > 0) {

			$publisherExist = 1;

		} else {

			$publisherAdded = 'added';

			$insertPublisher = Controller::insertPublisher([
				'publisher_name' => $publisherName
			]);

		}

	}



	// UPDATE PUBLISHER FORM
	if(isset($_POST['updatePublisher'])){

		$publisherId = $_POST['publisherId'];
		$publisherName = $_POST['publisherName'];

		$countPublisher = View::countPublisher([
			'publisher_name' => $publisherName
		]);


		if($countPublisher > 0) {

			$publisherExist = 1;

		} else {

			$updatePublisher = Controller::updatePublisher([
				'publisher_name' => $publisherName,
			], ['publisher_id' => $publisherId]);

			$publisherUpdated = 'updated';
		}

	}
	// END UPDATE PUBLISHER FORM



	// ADD DEPARTMENT FORM
	if(isset($_POST['addDepartment'])){

		$departmentName = $_POST['departmentName'];

		$countDepartment = View::countDepartment([
			'department_name' => $departmentName
		]);


		if($countDepartment > 0) {

			$departmentExist = 1;

		} else {

			$departmentAdded = 'added';

			$insertDepartment = Controller::insertDepartment([
				'department_name' => $departmentName
			]);

		}

	}



	// UPDATE DEPARTMENT FORM
	if(isset($_POST['updateDepartment'])){

		$departmentId = $_POST['departmentId'];
		$departmentName = $_POST['departmentName'];

		$countDepartment = View::countDepartment([
			'department_name' => $departmentName
		]);


		if($countDepartment > 0) {

			$departmentExist = 1;

		} else {

			$updateDepartment = Controller::updateDepartment([
				'department_name' => $departmentName,
			], ['department_id' => $departmentId]);

			$departmentUpdated = 'updated';
		}

	}
	// END UPDATE DEPARTMENT FORM



	// DISPLAY CATEGORIES
	$fetchCategories = View::fetchCategories();
	$categoryNumber = 1;



	// DISPLAY PUBLISHERS
	$fetchPublishers = View::fetchPublishers();
	$publisherNumber = 1;


	// DISPLAY DEPARTMENTS
	$fetchDepartments = View::fetchDepartments();
	$departmentNumber = 1;




	// DISPLAY ALL BOOKS
	$fetchBooks = View::fetchBooks();
	// echo '<pre>';
	// var_dump($fetchBooks); exit();
	// echo '</pre>';


	// DISPLAY ALL BOOKS FOR CIRCULATION
	$fetchBooksCirculation = array_filter($fetchBooks, function($circulation){
		return $circulation->type == 'Circulation';
	});

	// DISPLAY ALL BOOKS FOR RESERVED
	$fetchBooksReserved = array_filter($fetchBooks, function($reserved){
		return $reserved->type == 'Reserved';
	});

	// DISPLAY ALL USERS
	$fetchUsers = View::fetchUsers();


	?>	

	<?php require 'header.php'; ?>


	<section id="showcase">
		<!-- header -->
		<div class="content-header d-flex justify-content-between align-items-center container">
			<h3>MAINTENANCE</h3>
		</div>	

		<!-- tabs pannels -->
		<div id="maintenance" class="container">

			<ul class="nav nav-tabs first-tab pt-2" id="myTab" role="tablist">
				  <li class="nav-item" role="presentation">
				    <button class="nav-link active " data-bs-toggle="tab" data-bs-target="#category" type="button" role="tab" aria-controls="home" aria-selected="true">CATEGORY</button>
				  </li>

				   <li class="nav-item" role="presentation">
				    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#publisher" type="button" role="tab" aria-controls="contact" aria-selected="false">PUBLISHERS</button>
				  </li>

				   <li class="nav-item" role="presentation">
				    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#department" type="button" role="tab" aria-controls="contact" aria-selected="false">DEPARTMENT</button>
				  </li>

				  <li class="nav-item" role="presentation">
				    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#borrowers" type="button" role="tab" aria-controls="profile" aria-selected="false">BORROWERS</button>
				  </li>
				  
				  <li class="nav-item" role="presentation">
				    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#books" type="button" role="tab" aria-controls="profile" aria-selected="false">BOOKS</button>
				  </li>

				  <li class="nav-item" role="presentation">
				    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#user" type="button" role="tab" aria-controls="contact" aria-selected="false">USERS</button>
				  </li>
				
				  <li class="nav-item" role="presentation">
				    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#setting" type="button" role="tab" aria-controls="contact" aria-selected="false">BUSINESS RULES</button>
				  </li>
			</ul>

				<!-- all the tab content in maintenance -->
				<div class="tab-content pt-2" id="myTabContent">

					<!-- start category tab content -->
				  <div class="tab-pane fade show active bg-light text-dark container" id="category">
				  	<!-- category add form -->
				  	<form method="POST" action="admin-maintenance">
				  		<div class="form-group d-flex py-1">
				  			<input class="form-control w-25 mx-2" type="text" name="categoryName" placeholder="Category Name" required="">
				  			<input class="btn custombtn mx-2" type="submit" name="addCategory" value="ADD CATEGORY">
				  		</div>
				  	</form>
				  	<!-- category end add form -->

				  	<!-- category tables -->
				  	<div class="mt-3">

					  	<table id="category-tables" class="table table-striped mt-1">
						 	<thead>
						 		<tr>
						 			<th>
						 				#
						 			</th>
						 			<th>
						 				Category Name
						 			</th>
						 			<th><i class="fas fa-cog"></i></th>
						 		</tr>
						 	</thead>
						 	<tbody>
						 		
						 		<?php foreach($fetchCategories as $category) : ?>
						 			<tr>
						 				<td><?= $categoryNumber++; ?></td>
						 				<td><?= $category->category_name; ?></td>
						 				<td class="table-icon">

						 					<!-- button for update category -->
						 					<button class="fas fa-edit button-icon" title="Edit" style="border:none; outline-style: none;" id="updateCategory" data-bs-toggle="modal" data-bs-target="#updateCategoryModal" value="<?= $category->category_id; ?>">
						 					</button>


						 					<?php 

						 					$countBookCategory = View::countBookCategory([
						 						'category_name' => $category->category_name
						 					]);

						 					


						 					if($countBookCategory > 0) : 

						 					?>

					 						<!-- button for delete category -->
					 						<button class="fas fa-trash button-icon" title="Can't Delete" style="border:none; outline-style: none;" id="deleteCategory" value="<?= $category->category_id; ?>" disabled>
					 						</button>

						 					<?php else: ?>

					 						<!-- button for delete category -->
					 						<button class="fas fa-trash button-icon" title="Delete" style="border:none; outline-style: none;" id="deleteCategory" value="<?= $category->category_id; ?>">
					 						</button>

						 					<?php endif; ?>

						 					

						 				</td>
						 			</tr>
						 		<?php endforeach; ?>
						 			
						 	</tbody>
						 	<tfoot>
						 		<tr>
						 			<th>
						 				#
						 			</th>
						 			<th>
						 				Category Name
						 			</th>
						 			<th><i class="fas fa-cog"></i></th>
						 		</tr>
						 	</tfoot>
						</table>
						
						<!-- Modal for category update -->
						<?php require 'modals/edit/editcategorymodal.php'; ?>
						<!-- End for Category update modal -->


					</div>
					<!-- end of category tables -->
				  </div>
				  <!-- end of category tab content -->


				  <!-- start of publisher tab content -->
				    <div class="tab-pane fade bg-light text-dark container" id="publisher">
				    	<!-- publisher add form -->
				    	<form method="POST" action="admin-maintenance">
				    		<div class="form-group d-flex py-1">
				    			<input class="form-control w-25 mx-2" type="text" name="publisherName" placeholder="Publisher Name" required>
				    			<input class="btn custombtn mx-2" type="submit" name="addPublisher" value="ADD PUBLISHER">
				    		</div>
				    	</form>
				    	<!-- publisher end add form -->

				    	<!-- publisher tables -->
				    	<div class="mt-3">

				  	  	<table id="publisher-tables" class="table table-striped mt-1">
				  		 	<thead>
				  		 		<tr>
				  		 			<th>
				  		 				#
				  		 			</th>
				  		 			<th>
				  		 				Publisher Name
				  		 			</th>
				  		 			<th><i class="fas fa-cog"></i></th>
				  		 		</tr>
				  		 	</thead>
				  		 	<tbody>
				  		 		
				  		 		<?php foreach($fetchPublishers as $publisher) : ?>
				  		 			<tr>
				  		 				<td><?= $publisherNumber++; ?></td>
				  		 				<td><?= $publisher->publisher_name; ?></td>
				  		 				<td class="table-icon">

				  		 					<!-- button for update publiser -->
				  		 					<button class="fas fa-edit button-icon" title="Edit" style="border:none; outline-style: none;" id="updatePublisher" data-bs-toggle="modal" data-bs-target="#updatePublisherModal" value="<?= $publisher->publisher_id; ?>">
				  		 					</button>


				  		 					<?php 

				  		 					$countBookPublisher = View::countBookPublisher([
				  		 						'publisher_name' => $publisher->publisher_name
				  		 					]);


				  		 					if($countBookPublisher > 0) : 

				  		 					?>

				  	 						<!-- button for delete category -->
				  	 						<button class="fas fa-trash button-icon" title="Can't Delete" style="border:none; outline-style: none;" id="deletePublisher" value="<?= $publisher->publisher_id; ?>" disabled>
				  	 						</button>

				  		 					<?php else: ?>

				  	 						<!-- button for delete category -->
				  	 						<button class="fas fa-trash button-icon" title="Delete" style="border:none; outline-style: none;" id="deletePublisher" value="<?= $publisher->publisher_id; ?>">
				  	 						</button>

				  		 					<?php endif; ?>

				  		 					

				  		 				</td>
				  		 			</tr>
				  		 		<?php endforeach; ?>
				  		 			
				  		 	</tbody>
				  		 	<tfoot>
				  		 		<tr>
				  		 			<th>
				  		 				#
				  		 			</th>
				  		 			<th>
				  		 				Publisher Name
				  		 			</th>
				  		 			<th><i class="fas fa-cog"></i></th>
				  		 		</tr>
				  		 	</tfoot>
				  		</table>
				  		
				  		<!-- Modal for publisher update -->
				  		<?php require 'modals/edit/editpublishermodal.php'; ?>
				  		<!-- End for publisher update modal -->


				  	</div>
				  	<!-- end of publisher tables -->
				    </div>
				    <!-- end of publisher tab content -->





				    <!-- start of department tab content -->
				      <div class="tab-pane fade bg-light text-dark container" id="department">
				      	<!-- department add form -->
				      	<form method="POST" action="admin-maintenance">
				      		<div class="form-group d-flex py-1">
				      			<input class="form-control w-25 mx-2" type="text" name="departmentName" placeholder="Department Name" required>
				      			<input class="btn custombtn mx-2" type="submit" name="addDepartment" value="ADD DEPARTMENT">
				      		</div>
				      	</form>
				      	<!-- department end add form -->

				      	<!-- department tables -->
				      	<div class="mt-3">

				    	  	<table id="department-tables" class="table table-striped mt-1">
				    		 	<thead>
				    		 		<tr>
				    		 			<th>
				    		 				#
				    		 			</th>
				    		 			<th>
				    		 				Department Name
				    		 			</th>
				    		 			<th><i class="fas fa-cog"></i></th>
				    		 		</tr>
				    		 	</thead>
				    		 	<tbody>
				    		 		
				    		 		<?php foreach($fetchDepartments as $department) : ?>
				    		 			<tr>
				    		 				<td><?= $departmentNumber++; ?></td>
				    		 				<td><?= $department->department_name; ?></td>
				    		 				<td class="table-icon">

				    		 					<!-- button for update department -->
				    		 					<button class="fas fa-edit button-icon" title="Edit" style="border:none; outline-style: none;" id="updateDepartment" data-bs-toggle="modal" data-bs-target="#updateDepartmentModal" value="<?= $department->department_id; ?>">
				    		 					</button>


				    		 					<?php 

				    		 					$countBookDepartment = View::countBookDepartment([
				    		 						'department_name' => $department->department_name
				    		 					]);


				    		 					if($countBookDepartment > 0) : 

				    		 					?>

				    	 						<!-- button for delete department -->
				    	 						<button class="fas fa-trash button-icon" title="Can't Delete" style="border:none; outline-style: none;" id="deleteDepartment" value="<?= $department->department_id; ?>" disabled>
				    	 						</button>

				    		 					<?php else: ?>

				    	 						<!-- button for delete department -->
				    	 						<button class="fas fa-trash button-icon" title="Delete" style="border:none; outline-style: none;" id="deleteDepartment" value="<?= $department->department_id; ?>">
				    	 						</button>

				    		 					<?php endif; ?>

				    		 					

				    		 				</td>
				    		 			</tr>
				    		 		<?php endforeach; ?>
				    		 			
				    		 	</tbody>
				    		 	<tfoot>
				    		 		<tr>
				    		 			<th>
				    		 				#
				    		 			</th>
				    		 			<th>
				    		 				Publisher Name
				    		 			</th>
				    		 			<th><i class="fas fa-cog"></i></th>
				    		 		</tr>
				    		 	</tfoot>
				    		</table>
				    		
				    		<!-- Modal for department update -->
				    		<?php require 'modals/edit/editdepartmentmodal.php'; ?>
				    		<!-- End for department update modal -->


				    	</div>
				    	<!-- end of department tables -->
				      </div>
				      <!-- end of department tab content -->



				      <!-- start of department tab content -->
				        <div class="tab-pane fade bg-light text-dark container" id="borrowers">

				   		     <div class="d-flex justify-content-center flex-column">

				   		     	<div style="background-color: royalblue;" class="w-100 text-light p-2 mb-4">
				   		     		<p class=" my-auto p-1" >Import Data From Exel</p>
				   		     	</div>

				   		     	<div class="mx-auto text-danger border border-danger mb-4" style="width: 80%;">
				   		     		<p class=" my-auto p-3" id="fileMessage">Please Select File</p>
				   		     	</div>

				   		     	<form class="w-100 text-center mb-4" id="import_excel_form" enctype="multipart/form-data">
				        			<input type="file" id="import_excel_file">
				        			<input type="submit" id="import" value="Import" class="px-2 btn btn-primary">
				        		</form>

				        	</div>			
				        	
				        </div>
				        <!-- end of department tab content -->



				  <!-- books tab content -->
				  <div class="tab-pane fade bg-light text-dark container" id="books">
				  	<!-- sub tab pannel of book tab pannel -->
					  <div class="d-flex justify-content-between py-1 align-items-center border-bottom border-secondary">

					  	<ul class="nav nav-tabs second-tab pt-2" id="myTab" role="tablist">
					  		  <li class="nav-item" role="presentation">
					  		    <button class="nav-link active " data-bs-toggle="tab" data-bs-target="#all" type="button" role="tab" aria-controls="home" aria-selected="true">All</button>
					  		  </li>
					  		  <li class="nav-item" role="presentation">
					  		    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#circulation" type="button" role="tab" aria-controls="profile" aria-selected="false">Circulation</button>
					  		  </li>
					  		  <li class="nav-item" role="presentation">
					  		    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#reserved" type="button" role="tab" aria-controls="contact" aria-selected="false">Reserved</button>
					  		 </li>
					  	</ul>
					  	<!-- add book button -->
					  	  <button class="custombtn btn" data-bs-toggle="modal" data-bs-target="#addBookModal">Add book</button>

					  	  <!-- Modal for add books -->
					  	  <?php require 'modals/add/addbooksmodal.php'; ?>
					  	  <!-- End for add books modal -->


					  </div>	
					
					<!-- sub tab pannel content -->
					  <div class="tab-content pt-2" id="myTabContent">
					  	 <!-- sub tab pannel all book content-->

					  	  <div class="tab-pane fade show active bg-light text-dark text-center" id="all">

					  	  	<table id="book-tables" class="table table-striped mt-3" style="width:100%">
					  	  	        <thead>
					  	  	            <tr>
					  	  	                <th>Accession</th>
					  	  	                <th>Category</th>
					  	  	                <th>Title</th>
					  	  	                <th>DDC</th>
					  	  	                <th>Author</th>
					  	  	                <th>Publisher</th>
					  	  	                <th>Place Publication</th>
					  	  	                <th>Date Added</th>
					  	  	                <th><i class="fas fa-cog"></i></th>
					  	  	            </tr>
					  	  	        </thead>
					  	  	        <tbody id="book-info">
					  	  	        	<?php foreach($fetchBooks as $book) : ?>
					  	  	            <tr>
					  	  	                <td><?= $book->accession_id; ?></td>
					  	  	                <td><?= $book->category_name;?></td>
					  	  	                <td><?= $book->title; ?></td>
					  	  	                <td><?= $book->ddc ?></td>
					  	  	                <td><?= $book->author; ?></td>
					  	  	                <td><?= $book->publisher_name; ?></td>
					  	  	                <td><?= $book->placeofpublication; ?></td>
					  	  	                <td><?= $book->date_added; ?></td>
					  	  	                <td>
					  	  	                	<div class="d-flex flex-column text-center">

					  	  	                			<button data-bs-toggle="modal" data-bs-target="#allBookCopyModal" value="<?= $book->accession_id; ?>" class="button-icon fas fa-copy" title="Add copy" id="bookCopy"  style="border:none; outline-style: none;background-color: transparent;">
								  	  	                </button>

						  	  	                
								  	  	                <button data-bs-toggle="modal" data-bs-target="#allView" value="<?= $book->accession_id; ?>" class="button-icon fas fa-desktop" title="view" id="allBookModal"  style="border:none; outline-style: none;background-color: transparent;">
								  	  	                </button>

								  	  	                <button data-bs-toggle="modal" data-bs-target="#editAllView" value="<?= $book->accession_id; ?>" class="button-icon fas fa-edit" title="edit" id="editAllBookModal" style="border:none; outline-style: none;background-color: transparent;">
								  	  	               </button>

								  	  	               <?php 

								  	  	                	$countBookBorrowed = View::countBorrowedBook([
										 						'accession_id' => $book->accession_id
										 					]);


									  	  	                if($countBookBorrowed > 0) : ?>

									  	  	                	 <button value="<?= $book->accession_id; ?>" class="button-icon fas fa-trash " title="Can't delete" id="deleteBook" style="border:none; outline-style: none;background-color: transparent;" disabled>	
									  	  	                	 </button>

									  	  	                <?php else : ?>

									  	  	                	<button value="<?= $book->accession_id; ?>" class="button-icon fas fa-trash " title="delete" id="deleteBook" style="border:none; outline-style: none;background-color: transparent;">
									  	  	                	 </button>

									  	  	                <?php endif; ?>
							  	  	            	
								  	  	          

								  	  	                <?php if($book->broadcast == 1) : ?>


								  	  	                	<?php 

								  	  	                	$countBookBorrowed = View::countBorrowedBook([
										 						'accession_id' => $book->accession_id
										 					]);


									  	  	                if($countBookBorrowed > 0) : ?>

									  	  	                	 <button value="<?= $book->accession_id; ?>" class="button-icon fas fa-eye" title="Can't Unbroadcast" id="unbroadcast" style="border:none; outline-style: none;background-color: transparent;" disabled>
										  	  	                </button>

									  	  	                <?php else : ?>

									  	  	                	<button value="<?= $book->accession_id; ?>" class="button-icon fas fa-eye" title="Unbroadcast" id="unbroadcast" style="border:none; outline-style: none;background-color: transparent;">
										  	  	                </button>

									  	  	                <?php endif; ?>

									  	  	               

								  	  	            	<?php else: ?>

									  	  	                <button value="<?= $book->accession_id; ?>" class="button-icon fas fa-eye-slash" title="Broadcast" id="broadcast" style="border:none; outline-style: none;background-color: transparent;">
									  	  	                </button>

								  	  	            	<?php endif; ?>
							  	  	           
						  	  	            	</div>
					  	  	            	</td>
					  	  	            </tr>
					  	  	           <?php endforeach; ?>
					  	  	        </tbody>
					  	  	        <tfoot>
					  	  	            <tr>
					  	  	                <th>Accession</th>
					  	  	                <th>Category</th>
					  	  	                <th>Title</th>
					  	  	                <th>DDC</th>
					  	  	                <th>Author</th>
					  	  	                <th>Publisher</th>
					  	  	                <th>Place Publication</th>
					  	  	                <th>Date Added</th>
					  	  	                <th><i class="fas fa-cog"></i></th>
					  	  	            </tr>
					  	  	        </tfoot>
					  	  	    </table>

					  	  	    <!-- modal for view single book in all books tab panel -->
					  		 <?php require 'modals/view/allbookmodal.php'; ?>
					  		 <!-- End for view single book modal in all books tab panel -->

					  		  <!-- modal for edit single book in all books tab panel -->
					  		 <?php require 'modals/edit/editallbookmodal.php'; ?>
					  		 <!-- End for edit single book modal in all books tab panel -->

					  		 <?php require 'modals/add/allbookscopymodal.php'; ?>




					  	  </div>
					  	  <!-- end of sub tab pannel all book content-->

					  	  <!-- sub tab pannel circulation content -->
					  	  <div class="tab-pane fade bg-light text-dark text-center" id="circulation">

					  	  	  	<table id="circulation-tables" class="table table-striped mt-3" style="width:100%">
									<thead>
					  	  	            <tr>
					  	  	                <th>Accession</th>
					  	  	                <th>Category</th>
					  	  	                <th>Title</th>
					  	  	                <th>DDC</th>
					  	  	                <th>Author</th>
					  	  	                <th>Publisher</th>
					  	  	                <th>Place Publication</th>
					  	  	                <th>Date Added</th>
					  	  	                <th><i class="fas fa-cog"></i></th>
					  	  	            </tr>
					  	  	        </thead>
					  	  	        <tbody id="book-info">
					  	  	        	<?php foreach($fetchBooksCirculation as $book) : ?>
					  	  	            <tr>
					  	  	                <td><?= $book->accession_id; ?></td>
					  	  	                <td><?= $book->category_name;?></td>
					  	  	                <td><?= $book->title; ?></td>
					  	  	                <td><?= $book->ddc ?></td>
					  	  	                <td><?= $book->author; ?></td>
					  	  	                <td><?= $book->publisher_name; ?></td>
					  	  	                <td><?= $book->placeofpublication; ?></td>
					  	  	                <td><?= $book->date_added; ?></td>
					  	  	                <td>
					  	  	                	<div class="d-flex flex-column text-center">

					  	  	                			<button data-bs-toggle="modal" data-bs-target="#circulationBookCopyModal" value="<?= $book->accession_id; ?>" class="button-icon fas fa-copy" title="Add copy" id="bookCopy"  style="border:none; outline-style: none;background-color: transparent;">
								  	  	                </button>
					  	  	                			
					  	  	                		
								  	  	                <button data-bs-toggle="modal" data-bs-target="#circulationView" value="<?= $book->accession_id; ?>" class="button-icon fas fa-desktop" title="view" id="circulationBookModal"  style="border:none;
									               		outline-style: none;background-color: transparent;">
								  	  	                </button>

								  	  	                <button data-bs-toggle="modal" data-bs-target="#editCirculationView" value="<?= $book->accession_id; ?>" class="button-icon fas fa-edit" title="edit" id="editCirculationBookModal" style="border:none;
									               		outline-style: none;background-color: transparent;">
								  	  	                </button>
							  	  	           	

							  	  	           		 
								  	  	                <?php 

								  	  	                	$countBookBorrowed = View::countBorrowedBook([
										 						'accession_id' => $book->accession_id
										 					]);


									  	  	                if($countBookBorrowed > 0) : ?>

									  	  	                	 <button value="<?= $book->accession_id; ?>" class="button-icon fas fa-trash " title="Can't delete" id="deleteBook" style="border:none; outline-style: none;background-color: transparent;" disabled>	
									  	  	                	 </button>

									  	  	                <?php else : ?>

									  	  	                	<button value="<?= $book->accession_id; ?>" class="button-icon fas fa-trash " title="delete" id="deleteBook" style="border:none; outline-style: none;background-color: transparent;">
									  	  	                	 </button>

									  	  	                <?php endif; ?>
							  	  	            	
								  	  	          

								  	  	                <?php if($book->broadcast == 1) : ?>


								  	  	                	<?php 

								  	  	                	$countBookBorrowed = View::countBorrowedBook([
										 						'accession_id' => $book->accession_id
										 					]);


									  	  	                if($countBookBorrowed > 0) : ?>

									  	  	                	 <button value="<?= $book->accession_id; ?>" class="button-icon fas fa-eye" title="Can't Unbroadcast" id="unbroadcast" style="border:none; outline-style: none;background-color: transparent;" disabled>
										  	  	                </button>

									  	  	                <?php else : ?>

									  	  	                	<button value="<?= $book->accession_id; ?>" class="button-icon fas fa-eye" title="Unbroadcast" id="unbroadcast" style="border:none; outline-style: none;background-color: transparent;">
										  	  	                </button>

									  	  	                <?php endif; ?>

									  	  	               

								  	  	            	<?php else: ?>

									  	  	                <button value="<?= $book->accession_id; ?>" class="button-icon fas fa-eye-slash" title="Broadcast" id="broadcast" style="border:none; outline-style: none;background-color: transparent;">
									  	  	                </button>

								  	  	            	<?php endif; ?>

						  	  	            	</div>
					  	  	            	</td>
					  	  	            </tr>
					  	  	           <?php endforeach; ?>
					  	  	        </tbody>
					  	  	        <tfoot>
					  	  	            <tr>
					  	  	                <th>Accession</th>
					  	  	                <th>Category</th>
					  	  	                <th>Title</th>
					  	  	                <th>DDC</th>
					  	  	                <th>Author</th>
					  	  	                <th>Publisher</th>
					  	  	                <th>Place Publication</th>
					  	  	                <th>Date Added</th>
					  	  	                <th><i class="fas fa-cog"></i></th>
					  	  	            </tr>
					  	  	        </tfoot>
					  	  		</table>

					  	  		<!-- modal for view single book in circulation books tab panel -->
					  	  		<?php require 'modals/view/circulationbookmodal.php'; ?>
					  	  		<!-- End for view single book modal in circulation books tab panel -->

					  	  		 <!-- modal for edit single book in circulation books tab panel -->
					  	  		<?php require 'modals/edit/editcirculationbookmodal.php'; ?>
					  	  		<!-- End for edit single book modal in circulation books tab panel -->

					  	  		<?php require 'modals/add/circulationbookscopymodal.php'; ?>

					  	  	



					  	  </div>
					  	  <!-- end of sub tab pannel circulation content -->

					  	  <!-- sub tab p for reserved -->
					  	  <div class="tab-pane fade bg-light text-dark text-center" id="reserved">

					  	  	  	<table id="reserved-tables" class="table table-striped mt-3" style="width:100%">
					  	  		 	<thead>
					  	  	            <tr>
					  	  	                <th>Accession</th>
					  	  	                <th>Category</th>
					  	  	                <th>Title</th>
					  	  	                <th>DDC</th>
					  	  	                <th>Author</th>
					  	  	                <th>Publisher</th>
					  	  	                <th>Place Publication</th>
					  	  	                <th>Date Added</th>
					  	  	                <th><i class="fas fa-cog"></i></th>
					  	  	            </tr>
					  	  	        </thead>
					  	  	        <tbody id="book-info">
					  	  	        	<?php foreach($fetchBooksReserved as $book) : ?>
					  	  	            <tr>
					  	  	                <td><?= $book->accession_id; ?></td>
					  	  	                <td><?= $book->category_name;?></td>
					  	  	                <td><?= $book->title; ?></td>
					  	  	                <td><?= $book->ddc ?></td>
					  	  	                <td><?= $book->author; ?></td>
					  	  	                <td><?= $book->publisher_name; ?></td>
					  	  	                <td><?= $book->placeofpublication; ?></td>
					  	  	                <td><?= $book->date_added; ?></td>
					  	  	                <td>
					  	  	                	<div class="d-flex flex-column text-center">

					  	  	                		<button data-bs-toggle="modal" data-bs-target="#reservedBookCopyModal" value="<?= $book->accession_id; ?>" class="button-icon fas fa-copy" title="Add copy" id="bookCopy"  style="border:none; outline-style: none;background-color: transparent;">
								  	  	            </button>


							  	  	                <button data-bs-toggle="modal" data-bs-target="#reservedView" value="<?= $book->accession_id; ?>" class="button-icon fas fa-desktop" title="view" id="reservedBookModal"  style="border:none;
								               		outline-style: none;background-color: transparent;">
							  	  	                </button>

							  	  	                <button data-bs-toggle="modal" data-bs-target="#editReservedView" value="<?= $book->accession_id; ?>" class="button-icon fas fa-edit" title="edit" id="editReservedBookModal" style="border:none;
								               		outline-style: none;background-color: transparent;">
							  	  	                </button>

							  	  	               <?php 

								  	  	                	$countBookBorrowed = View::countBorrowedBook([
										 						'accession_id' => $book->accession_id
										 					]);


									  	  	                if($countBookBorrowed > 0) : ?>

									  	  	                	 <button value="<?= $book->accession_id; ?>" class="button-icon fas fa-trash " title="Can't delete" id="deleteBook" style="border:none; outline-style: none;background-color: transparent;" disabled>	
									  	  	                	 </button>

									  	  	                <?php else : ?>

									  	  	                	<button value="<?= $book->accession_id; ?>" class="button-icon fas fa-trash " title="delete" id="deleteBook" style="border:none; outline-style: none;background-color: transparent;">
									  	  	                	 </button>

									  	  	                <?php endif; ?>
							  	  	            	
								  	  	          

								  	  	                <?php if($book->broadcast == 1) : ?>


								  	  	                	<?php 

								  	  	                	$countBookBorrowed = View::countBorrowedBook([
										 						'accession_id' => $book->accession_id
										 					]);


									  	  	                if($countBookBorrowed > 0) : ?>

									  	  	                	 <button value="<?= $book->accession_id; ?>" class="button-icon fas fa-eye" title="Can't Unbroadcast" id="unbroadcast" style="border:none; outline-style: none;background-color: transparent;" disabled>
										  	  	                </button>

									  	  	                <?php else : ?>

									  	  	                	<button value="<?= $book->accession_id; ?>" class="button-icon fas fa-eye" title="Unbroadcast" id="unbroadcast" style="border:none; outline-style: none;background-color: transparent;">
										  	  	                </button>

									  	  	                <?php endif; ?>

									  	  	               

								  	  	            	<?php else: ?>

									  	  	                <button value="<?= $book->accession_id; ?>" class="button-icon fas fa-eye-slash" title="Broadcast" id="broadcast" style="border:none; outline-style: none;background-color: transparent;">
									  	  	                </button>

								  	  	            	<?php endif; ?>
						  	  	          	  </div>
					  	  	            	</td>
					  	  	            </tr>
					  	  	           <?php endforeach; ?>
					  	  	        </tbody>
					  	  	        <tfoot>
					  	  	            <tr>
					  	  	                <th>Accession</th>
					  	  	                <th>Category</th>
					  	  	                <th>Title</th>
					  	  	                <th>DDC</th>
					  	  	                <th>Author</th>
					  	  	                <th>Publisher</th>
					  	  	                <th>Place Publication</th>
					  	  	                <th>Date Added</th>
					  	  	                <th><i class="fas fa-cog"></i></th>
					  	  	            </tr>
					  	  	        </tfoot>
					  	  		</table>

					  	  		<!-- modal for view single book in reserved books tab panel -->
					  	  		<?php require 'modals/view/reservedbookmodal.php'; ?>
					  	  		<!-- End for view single book in reserved books tab panel -->

					  	  		 <!-- modal for edit single book in reserved books tab panel -->
					  	  		<?php require 'modals/edit/editreservedbookmodal.php'; ?>
					  	  		<!-- End for edit single book modal in reserved books tab panel -->

					  	  		<?php require 'modals/add/reservedbookscopymodal.php'; ?>



					  	  </div>
					  	   <!-- end of sub tab pannel for reserved -->



					  </div>
				  </div>
				  <!-- end of books tab content -->



				  <!-- start of user tab content -->
				    <div class="tab-pane fade bg-light text-dark container" id="user">
				    	

				  	<div class="container mt-3">

				  		<div class="w-100 d-flex justify-content-end pb-3">
				  		 <button class="custombtn btn d-flex align-items-end" data-bs-toggle="modal" data-bs-target="#addUserFormModal">Add User</button>
				  		</div> 

				  		<!--start Modal for add user -->
				  		<?php require 'modals/add/addusermodal.php'; ?>
				  		<!-- end Modal for add user -->
				  		

				  		<table id="user-tables" class="table table-striped mt-3 text-center" style="width:100%">

				  	        <thead>
				  	            <tr>
				  	                <th>Last name</th>
				  	                <th>First name</th>
				  	                <th>Middle name</th>
				  	                <th>Username</th>
				  	                <th>Type</th>
				  	                <th>Contact number</th>
				  	               <th><i class="fas fa-cog"></i></th>
				  	            </tr>
				  	        </thead>
				  	        <tbody>

				  	        	<?php foreach($fetchUsers as $user) : ?>
				  	            <tr>
				  	                <td><?= ucwords($user->lastname); ?></td>
				  	                <td><?= ucwords($user->firstname); ?></td>
				  	                <td><?= ucwords($user->middlename); ?></td>
				  	                <td><?= ucwords($user->username); ?></td>
				  	                <td><?= ucwords($user->type); ?></td>
				  	                <td><?= ucwords($user->contactnumber); ?></td>
				  	                <td>
				  				 		 <button class="fas fa-edit button-icon" id="updateUser" title="Edit" style="border:none; 
				  		               		outline-style: none;background-color: transparent;" data-bs-toggle="modal" data-bs-target="#updateUserFormModal"  value="<?= $user->user_id; ?>">
				  				 		</button>

				  				 		<?php if($user->type == 'admin') : ?>
					  				 		 <button class="fas fa-trash button-icon" id="deleteUser"  value="<?= $user->user_id; ?>" title="Delete" style="border:none; 
					  		               		outline-style: none;background-color: transparent;" disabled>
					  				 		</button>
				  				 		<?php else : ?>
				  				 			<button class="fas fa-trash button-icon" id="deleteUser"  value="<?= $user->user_id; ?>" title="Delete" style="border:none; 
				  		               		outline-style: none;background-color: transparent;">
				  				 			</button>
				  				 		<?php endif; ?>
				  					</td>
				  	            </tr>
				  	        	<?php endforeach; ?>
				  	        	
				  	            
				  	        </tbody>
				  	        <tfoot>
				  	          <tr>
				  	                <th>Last name</th>
				  	                <th>First name</th>
				  	                <th>Middle name</th>
				  	                <th>Username</th>
				  	                <th>Type</th>
				  	                <th>Contact number</th>
				  	               <th><i class="fas fa-cog"></i></th>
				  	            </tr>
				  	        </tfoot>
				  	    
				     		 </table>	


				     		 <?php require 'modals/edit/editusermodal.php'; ?>
				     		
				  	
				  	</div>
				  	
				    </div>
				    <!-- end of user tab content -->





				  <!-- tab pannel of settings  -->
				  <div class="tab-pane fade bg-light text-dark rules" id="setting">

				  	

				  		<form  id="changeRules" class="w-50 m-auto p-2">
				  		  <div class="mb-1">
				  		    <label class="form-label">Number of books allowed to borrow</label>
				  		    <input type="number" class="form-control" value="<?= $fetchRules->allowed_books; ?>" disabled>
				  		  </div>

				  		  <div class="mb-1">
				  		    <label  class="form-label">Number of days allowed</label>
				  		    <input type="number" class="form-control" value="<?= $fetchRules->allowed_days; ?>" disabled>
				  		  </div>

				  		  <div class="mb-1">
				  		    <label class="form-label">Overdue Date Penalty</label>
				  		    <input type="number" class="form-control" value="<?= $fetchRules->overdue_penalty; ?>" disabled>
				  		  </div>
				  		  <div class="mb-1">
				  		    <label class="form-label">Book Damaged Penalty</label>
				  		    <input type="number" class="form-control" value="<?= $fetchRules->damaged_penalty; ?>" disabled>
				  		  </div>
				  		  <div class="mb-1">
				  		    <label class="form-label">Book Lost Penalty</label>
				  		    <input type="number" class="form-control" value="<?= $fetchRules->lost_penalty; ?>" disabled>
				  		  </div>
				  		  <button type="submit" class="btn btn-primary mt-1 w-100">Change Rules</button>
				  		</form>

			


				  </div>
			</div>
		</div>

	</section>



	<?php require 'footer.php'; ?>


	<script>


		// CATEGORY AUTHENTICATION
		<?php if(isset($categoryExist) && $categoryExist == 1) : ?>
			alert('ERROR: CATEGORY NAME ALREADY EXIST!');
		<?php endif; ?>

		<?php if(isset($categoryAdded) && $categoryAdded == 'added') : ?>
			alert('NEW CATEGORY SUCCESSFULLY ADDED!');
		<?php endif; ?>

		<?php if(isset($categoryUpdated) && $categoryUpdated == 'updated') : ?>
			alert('NEW CATEGORY SUCCESSFULLY UPDATED!');
		<?php endif; ?>

		// PUBLISHER AUTHENTICATION
		<?php if(isset($publisherExist) && $publisherExist == 1) : ?>
			alert('ERROR: PUBLISHER NAME ALREADY EXIST!');
		<?php endif; ?>

		<?php if(isset($publisherAdded) && $publisherAdded == 'added') : ?>
			alert('NEW PUBLISHER SUCCESSFULLY ADDED!');
		<?php endif; ?>

		<?php if(isset($publisherUpdated) && $publisherUpdated == 'updated') : ?>
			alert('NEW PUBLISHER SUCCESSFULLY UPDATED!');
		<?php endif; ?>

		// DEPARTMENT AUTHENTICATION
		<?php if(isset($departmentExist) && $departmentExist == 1) : ?>
			alert('ERROR: DEPARTMENT NAME ALREADY EXIST!');
		<?php endif; ?>

		<?php if(isset($departmentAdded) && $departmentAdded == 'added') : ?>
			alert('NEW DEPARTMENT SUCCESSFULLY ADDED!');
		<?php endif; ?>

		<?php if(isset($departmentUpdated) && $departmentUpdated == 'updated') : ?>
			alert('NEW DEPARTMENT SUCCESSFULLY UPDATED!');
		<?php endif; ?>


	</script>




