<!DOCTYPE html>
<html>
<head>
	<title>login form</title>
	<!-- online bootstrap linkss -->
	<!--  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
	 <link rel="stylesheet" type="text/css" href="css/loginform.css">
	<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;500&display=swap" rel="stylesheet"> -->

	<!-- offline links -->
	<link rel="stylesheet" type="text/css" href="css/bootstrap/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/loginform.css">
	<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;500&display=swap" rel="stylesheet">
</head>


<body>
	<div class="r-color">
		
	</div>
	<div class="form-container">
		<div class="form-content w-100 h-100 d-flex">
			<div class="logo-form d-flex flex-column text-center">			
				<img class="cec-logo" src="images/logo.png">
			</div>

			<form id="login" class="d-flex flex-column justify-content-center align-items-center">	
				<h2 class="text-secondary">Log in</h2>

				<div id="loginform-inputs" class="w-50">

					<div class="form-floating mb-3 w-100">
					  <input type="text" class="form-control loginUsername" id="floatingInput" placeholder="Username" required autocomplete="off">
					  <label for="floatingInput">Username</label>
					</div>

					<div class="form-floating mb-3 w-100">
					  <input type="password" class="form-control loginPassword" id="floatingPassword" placeholder="Password" required autocomplete="off">
					  <label for="floatingPassword">Password</label>
					</div>	
				</div>	
				
				<div class="d-flex justify-content-end w-50">
					<a class=" d-block text-reset text-decoration-none mt-1" data-bs-toggle="modal" data-bs-target="#updateUserAccountModal" href="" id="changePassword">Forgot password?</a>
				</div>
				<button type="submit" class="button btn btn-primary w-50">Log in</button>
			</form>
		</div>
	</div>

	<?php require 'modals/edit/edituseraccountmodal.php'; ?>

	<!-- offline links for development-->
	<script src="js/bootstrap/bootstrap.bundle.min.js"></script>
	<script src="js/jquery/offline-jquery.js"></script>
	<script src="js/gsap/offline-gsap.min.js"></script>
	<script src="js/loginform.js"></script>	

	<!-- online links for production -->
	<!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>
	<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.6.0/gsap.min.js" integrity="sha512-1dalHDkG9EtcOmCnoCjiwQ/HEB5SDNqw8d4G2MKoNwjiwMNeBAkudsBCmSlMnXdsH8Bm0mOd3tl/6nL5y0bMaQ==" crossorigin="anonymous"></script>
	<script src="js/loginform.js"></script>	 -->
	
	
</body>
</html>