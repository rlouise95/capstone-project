<?php

	
	if(empty($_SESSION)){
		header("Location: login?access-denied!");
	}


	if($_SESSION['type'] == 'admin'){

		$pages = [
			[
				'name' => 'Dashboard',
				'icon' => 'fas fa-tachometer-alt',
				'url' => '/capstoneproject/admin-dashboard'
			],
			[
				'name' => 'Maintenance',
				'icon' => 'fas fa-user-cog',
				'url' => '/capstoneproject/admin-maintenance'
			],
			[
				'name' => 'Student List',
				'icon' => 'fas fa-user',
				'url' => '/capstoneproject/admin-student'
			],
			[
				'name' => 'Teacher List',
				'icon' => 'fas fa-user',
				'url' => '/capstoneproject/admin-teacher'
			],
			[
				'name' => 'Book Available',
				'icon' => 'fas fa-book',
				'url' => '/capstoneproject/admin-bookavailable'
			],
			[
				'name' => 'Book Borrowed',
				'icon' => 'fas fa-book-open',
				'url' => '/capstoneproject/admin-bookborrowed'
			],
			[
				'name' => 'Book Returned',
				'icon' => 'fas fa-undo-alt',
				'url' => '/capstoneproject/admin-bookreturned'
			]
		];

	} else {
		
		$pages = [
			[
				'name' => 'Student List',
				'icon' => 'fas fa-user',
				'url' => '/capstoneproject/admin-student'
			],
			[
				'name' => 'Teacher List',
				'icon' => 'fas fa-user',
				'url' => '/capstoneproject/admin-teacher'
			],
			[
				'name' => 'Book Available',
				'icon' => 'fas fa-book',
				'url' => '/capstoneproject/admin-bookavailable'
			],
			[
				'name' => 'Book Borrowed',
				'icon' => 'fas fa-book-open',
				'url' => '/capstoneproject/admin-bookborrowed'
			],
			[
				'name' => 'Book Returned',
				'icon' => 'fas fa-undo-alt',
				'url' => '/capstoneproject/admin-bookreturned'
			]
		];
	}



?>


	<!DOCTYPE html>
<html>
<head>
	<title>CEC LIBRARY INTEGRATED SYSTEM</title>
	<!-- dataTables -->
		<link rel="stylesheet" type="text/css" href="css/dataTables/jquery.dataTables.min.css">
		<link rel="stylesheet" type="text/css" href="css/dataTables/buttons.dataTables.min.css">

		<link rel="stylesheet" type="text/css" href="css/bootstrap/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="css/style.css">
		<link rel="stylesheet" type="text/css" href="css/fontawesome/css/all.css">
</head>
<body>
	<main>
		<header>
			<div class="logo-container">
				<div class="logo-wrapper">
					<h3>LIBRARY</h3>
					<img id="logo" src="images/logo.png">
					<h3>SYSTEM</h3>
				</div>
			</div>
		</header>
	</main>
			<aside>
				<nav>
					<div class="pro-id">
						<img id="pro-pic" src="images/pawiks.png">
						<h4><?= ucwords($_SESSION['lastname']); ?></h4>
						<?php if($_SESSION['type'] === 'admin') : ?>
						<p>ADMIN/LIBRARIAN</p>
						<?php else: ?>
						<p>LIBRARY STAFF</p>
						<?php endif; ?>
					</div>
					<ul class="nav-list">

						<?php foreach($pages as $page) : ?>
						<li class="customLinks <?= $page['url'] == $_SERVER['REQUEST_URI'] ? 'customActive' : ''?>">
							<a class="menu text-reset " href="<?= $page['url']; ?>">
								<i class="<?= $page['icon']; ?>"></i><?= $page['name']; ?>
							</a>
						</li>
						<?php endforeach; ?>

						<li class="customLinks">
							<a class="menu text-reset" href="logout">
								<i class="fas fa-sign-out-alt"></i>Logout
							</a>
						</li>
					
					</ul>
				</nav>
			</aside>