<?php 

// add student
if(isset($_POST['addborrower'])){
	$idnumber = $_POST['idnumber'];
	$lastname = $_POST['lastname'];
	$firstname = $_POST['firstname'];
	$middlename = $_POST['middlename'];
	$department = $_POST['department'];
	$contactnumber = $_POST['contactnumber'];
	$type = $_POST['type'];

	$countBorrower = View::countBorrower([
		'idnumber' => $idnumber
	]);

	if($countBorrower > 0){

		$borrowerExist = 1;

	} else {

		if(!preg_match("/^[a-zA-Z ]*$/", $firstname) || !preg_match("/^[a-zA-Z ]*$/", $middlename) || !preg_match("/^[a-zA-Z ]*$/", $lastname)){

			$errorData = 1;

		} else {

			if(strlen($contactnumber) != 11){

				$errorContact = 1;

			} else {

				$insertBorrower = Controller::insertBorrower([
					'idnumber' => $idnumber,
					'firstname' => $firstname,
					'middlename' => $middlename,
					'lastname' => $lastname,
					'department_id' => $department,
					'contactnumber' => $contactnumber,
					'type' => $type
				]);

				$success = 1;
			}

		}

	}

}



// edit student
if(isset($_POST['editborrower'])){
	$idnumber = $_POST['idnumber'];
	$lastname = $_POST['lastname'];
	$firstname = $_POST['firstname'];
	$middlename = $_POST['middlename'];
	$department = $_POST['department'];
	$contactnumber = $_POST['contactnumber'];
	$type = $_POST['type'];


		if(!preg_match("/^[a-zA-Z ]*$/", $firstname) || !preg_match("/^[a-zA-Z ]*$/", $middlename) || !preg_match("/^[a-zA-Z ]*$/", $lastname)){

			$errorData = 1;

		} else {

			if(strlen($contactnumber) != 11){

				$errorContact = 1;

			} else {

				$updateBorrower = Controller::updateBorrower([
					'firstname' => $firstname,
					'middlename' => $middlename,
					'lastname' => $lastname,
					'department_id' => $department,
					'contactnumber' => $contactnumber,
					'type' => $type
				], ['idnumber' => $idnumber]);

				$editsuccess = 1;
			}

		}

}

$fetchDepartments = View::fetchDepartments();

$fetchBorrowers = View::fetchBorrowers();

$fetchStudent = array_filter($fetchBorrowers, function($student){
	return $student->type == 'Student';
});


?>
		<?php require 'header.php'; ?>


					<section id="showcase">
						<!-- header -->
						<div class="content-header d-flex justify-content-between align-items-center container">
							<h3>STUDENT LIST</h3>
						</div>	

						
						<div id="student" class="container mt-5">

							<div class="w-100 d-flex justify-content-end pb-3">
							 <button class="custombtn btn d-flex align-items-end" data-bs-toggle="modal" data-bs-target="#addStudentFormModal">Add Student</button>
							</div> 

							<!-- Modal for add students -->
							<div class="modal fade" id="addStudentFormModal">
							  <div class="modal-dialog modal-dialog-scrollable modal-lg">
							    <div class="modal-content">
							      <div class="modal-header">
							        <h5 class="modal-title" id="exampleModalLabel">Add new student</h5>
							        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
							      </div>
							      <form method="POST" action="admin-student">

							      <div class="modal-body">
							        
							      	<div class="row">
							      		<div class="col-lg-12">
							      			<div class="form-floating mb-3">
							      			  <input type="number" name="idnumber" class="form-control" id="floatingInput" placeholder="ID number">
							      			  <label for="floatingInput">ID number</label>
							      			</div>
							      			<div class="form-floating mb-3">
							      			  <input type="text" name="lastname" class="form-control" id="floatingPassword" placeholder="Last name">
							      			  <label for="floatingPassword">Last name</label>
							      			</div>
							      			<div class="form-floating mb-3">
							      			  <input type="text" name="firstname" class="form-control" id="floatingInput" placeholder="First name">
							      			  <label for="floatingInput">First name</label>
							      			</div>
							      			<div class="form-floating mb-3">
							      			  <input type="text" name="middlename" class="form-control" id="floatingPassword" placeholder="Middle name">
							      			  <label for="floatingPassword">Middle name</label>
							      			</div>
							      			<div class="mb-3">
							      			  <label>-- SELECT COURSE --</label>
							      			  <br>
							      			<select name="department" class="form-select mb-3 mt-1">
							      			  <?php foreach($fetchDepartments as $department) : ?>
							      			  		<option value="<?= $department->department_id; ?>"><?= $department->department_name; ?></option>
							      			  <?php endforeach; ?>
							      			</select>
							      			</div>
							      			<div class="form-floating">
							      			  <input type="number" name="contactnumber" class="form-control" id="floatingPassword" placeholder="Contact number">
							      			  <label for="floatingPassword">Contact number</label>
							      			</div>
							      			<input type="hidden" name="type" value="Student">
							      		</div>
							      	</div>
							

							      </div>
							      <div class="modal-footer">
							        <button type="submit" name="addborrower" class="btn btn-primary">Add Student</button>
							      </div>

							      </form>
							    </div>
							  </div>
							</div>

							<table id="student-table" class="table table-striped mt-3 text-center" style="width:100%">

						        <thead>
						            <tr>
						                <th>ID number</th>
						                <th>Last name</th>
						                <th>First name</th>
						                <th>Middle name</th>
						                <th>Course</th>
						                <th>Contact number</th>
						               <th><i class="fas fa-cog"></i></th>
						            </tr>
						        </thead>
						        <tbody>

						        	<?php foreach($fetchStudent as $student) : ?>
						            <tr>
						                <td><?= $student->idnumber; ?></td>
						                <td><?= $student->lastname; ?></td>
						                <td><?= $student->firstname; ?></td>
						                <td><?= $student->middlename; ?></td>
						                <td><?= $student->department_name; ?></td>
						                <td><?= $student->contactnumber; ?></td>
						                <td>
							                <button class="fas fa-desktop button-icon" title="Borrowed History" style="border:none; 
							               		outline-style: none;background-color: transparent;" data-bs-toggle="modal" data-bs-target="#viewHistory" id="viewBorrowerHistory" value="<?= $student->idnumber; ?>">
									 		</button>

									 		 <button class="fas fa-edit button-icon" title="Edit" style="border:none; 
							               		outline-style: none;background-color: transparent;" data-bs-toggle="modal" data-bs-target="#updateStudentFormModal" id="editBorrower" value="<?= $student->idnumber; ?>">
									 		</button>

									 		<?php 

						 					$countBookBorrowed = View::countBorrowedBook([
						 						'idnumber' => $student->idnumber
						 					]);


						 					if($countBookBorrowed > 0) : 

						 					?>

									 		 <button class="fas fa-trash button-icon" id="deleteBorrower" value="<?= $student->idnumber; ?>" title="Delete" style="border:none; 
							               		outline-style: none;background-color: transparent;" disabled>
									 		<input type="hidden" id="borrowerType" value="<?= $student->type; ?>">
									 		</button>

									 		<?php else : ?>

				 					 		 <button class="fas fa-trash button-icon" id="deleteBorrower" value="<?= $student->idnumber; ?>" title="Delete" style="border:none; 
				 			               		outline-style: none;background-color: transparent;">
				 					 		<input type="hidden" id="borrowerType" value="<?= $student->type; ?>">
				 					 		</button>

									 		<?php endif; ?>
										</td>
						            </tr>
						        	<?php endforeach; ?>
						            
						        </tbody>
						        <tfoot>
						            <tr>
						                <th>ID number</th>
						                <th>Last name</th>
						                <th>First name</th>
						                <th>Middle name</th>
						                <th>Course</th>
						                <th>Contact number</th>
						                <th><i class="fas fa-cog"></i></th>
						            </tr>
						        </tfoot>
						    
					   		 </table>	

					   		<!-- modal for borrow history -->
					   		<?php require 'modals/view/viewborrowhistorymodal.php'; ?>

					   		 <div class="modal fade" id="updateStudentFormModal">
					   		   <div class="modal-dialog modal-dialog-scrollable modal-lg">
					   		     <div class="modal-content">
					   		       <div class="modal-header">
					   		         <h5 class="modal-title">Update student</h5>
					   		         <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
					   		       </div>
					   		       <form method="POST" action="admin-student" class="editBorrowerModal">


					   		       </form>
					   		     </div>
					   		   </div>
					   		 </div>
						
						</div>

					</section>



					<?php require 'footer.php'; ?>

					<script>

						<?php if(isset($borrowerExist)) : ?>

							window.alert('ERROR: Borrower ID number already Exist!');

						<?php endif; ?>
						
						<?php if(isset($errorData)) : ?>

							window.alert('ERROR: You inputed Invalid Characters!');

						<?php endif; ?>

						<?php if(isset($errorContact)) : ?>

							window.alert('ERROR: Invalid Contact Number!');

						<?php endif; ?>

						<?php if(isset($success)) : ?>

							window.alert('New Student Successfully Added!');

						<?php endif; ?>

						<?php if(isset($editsuccess)) : ?>

							window.alert('New Student Successfully Updated!');

						<?php endif; ?>

					</script>
		