		<?php

			if($_SESSION['type'] != 'admin'){
				header("Location: admin-student");
			}

			$countAllCategories = View::countAllCategories();

			$countAllPublishers = View::countAllPublishers();

			$countAllDepartments = View::countAllDepartments();

			$countAllUsers = View::countAllUsers();

			$countAllBooks = View::countAllBooks();

			$countAllTeachers = View::countAllTeachers([
				'type' => 'Teacher'
			]);

			$countAllStudents = View::countAllStudents([
				'type' => 'Student'
			]);


			$countBookAvailable = View::countBookAvailable([
				'broadcast' => 1
			]);

			$countDamagedBook = View::countDamagedBook([
				'return_status' => 'Return w/ Damaged'
			]);

			$countFinesDamagedBook = View::countDamagedBook([
				'return_status' => 'Return w/ Fines w/ Damaged'
			]);

			$countLostBook = View::countLostBook([
				'return_status' => 'Lost'
			]);

			$totalFines = View::totalFines();


			$countBookBorrowed = View::countBookBorrowed();

		 ?>
		<?php require 'header.php'; ?>


			<section id="showcase" >

					<div class="content-header d-flex justify-content-between align-items-center container">
						<h3>DASHBOARD</h3>
					</div>	

					<div class="p-4" id="dashboard">
						<div class="container mt-3 d-flex justify-content-around">
							<div class="card" style="width: 15rem;">
							  <div class="card-header p-3 text-light text-center">
							    CATEGORIES
							  </div>
							  <h1 class="card-text p-3 text-center"><?= $countAllCategories; ?></h1>
							</div>
							<div class="card" style="width: 15rem;">
							  <div class="card-header p-3 text-light text-center">
							    TOTAL BOOKS
							  </div>
							  <h1 class="card-text p-3 text-center"><?= $countAllBooks; ?></h1>
							</div>
							<div class="card" style="width: 15rem;">
							  <div class="card-header p-3 text-light text-center">
							    STUDENTS
							  </div>
							  <h1 class="card-text p-3 text-center"><?= $countAllStudents; ?></h1>
							</div>
							<div class="card" style="width: 15rem;">
							  <div class="card-header p-3 text-light text-center">
							    TEACHER
							  </div>
							  <h1 class="card-text p-3 text-center"><?= $countAllTeachers; ?></h1>
							</div>
						</div>

						<div class="container mt-3 d-flex justify-content-around">
							<div class="card" style="width: 15rem;">
							  <div class="card-header p-3 text-light text-center">
							    BOOK AVAILABLE
							  </div>
							  <h1 class="card-text p-3 text-center"><?= $countBookAvailable; ?></h1>
							</div>
							<div class="card" style="width: 15rem;">
							  <div class="card-header p-3 text-light text-center">
							    BOOK BORROWED
							  </div>
							  <h1 class="card-text p-3 text-center"><?= $countBookBorrowed; ?></h1>
							</div>
							<div class="card" style="width: 15rem;">
							  <div class="card-header p-3 text-light text-center">
							   	BOOK DAMAGE
							  </div>
							  <h1 class="card-text p-3 text-center"><?= $countDamagedBook + $countFinesDamagedBook; ?></h1>
							</div>
							<div class="card" style="width: 15rem;">
							  <div class="card-header p-3 text-light text-center">
							    BOOK LOST
							  </div>
							  <h1 class="card-text p-3 text-center"><?= $countLostBook; ?></h1>
							</div>
						</div>

						<div class="container mt-3 d-flex justify-content-around">
							<div class="card" style="width: 15rem;">
							  <div class="card-header p-3 text-light text-center">
							   USERS
							  </div>
							  <h1 class="card-text p-3 text-center"><?= $countAllUsers; ?></h1>
							</div>
							<div class="card" style="width: 15rem;">
							  <div class="card-header p-3 text-light text-center">
							    PUBLISHERS
							  </div>
							  <h1 class="card-text p-3 text-center"><?= $countAllPublishers; ?></h1>
							</div>

							<div class="card" style="width: 15rem;">
							  <div class="card-header p-3 text-light text-center">
							    DEPARTMENTS
							  </div>
							  <h1 class="card-text p-3 text-center"><?= $countAllDepartments ?? '0'; ?></h1>
							</div>

							<div class="card" style="width: 15rem;">
							  <div class="card-header p-3 text-light text-center">
							    FINES
							  </div>
							  <h1 class="card-text p-3 text-center"><?= $totalFines->fines ?? '0'; ?></h1>
							</div>

							
					</div>
			</section>



	<?php require 'footer.php'; ?>





