		<?php 


			$fetchReturnedBooks = View::fetchReturnedBooks();


		?>	


		<?php require 'header.php'; ?>


					<section id="showcase">
						<!-- header -->
						<div class="content-header d-flex justify-content-between align-items-center container">
							<h3>BOOK RETURNED</h3>
						</div>	

						
						<div id="book-returned" class="container mt-3">

										
																
								  	  	<table id="returned-book" class="table table-striped display" style="width:100%">
								  	  		
								  	  	        <thead>
								  	  	            <tr>
								  	  	                <th>Accession</th>
								  	  	                <th>Category</th>
								  	  	                <th>Title</th>
								  	  	                <th>Returned by</th>
								  	  	                <th>Recieve by</th>
								  	  	                <th>Date Borrowed</th>
								  	  	                <th>Date Returned</th>
								  	  	                <th>Book Status</th>
								  	  	                <th>Fines</th>
								  	  	            
								  	  	            </tr>
								  	  	        </thead>
								  	  	        <tbody id="book-info">
								  	  	        		

								  	  	        	<?php foreach($fetchReturnedBooks as $book) : ?>	
								  	  	            <tr>
								  	  	                <td><?= $book->accession_id; ?></td>
								  	  	                <td><?= $book->category_name; ?></td>
								  	  	                <td><?= $book->title; ?></td>	  	              
								  	  	                <td>
								  	  	                	<?= $book->borrower_idnumber; ?><br>
								  	  	                	<?= $book->borrower_lastname; ?> <br>
								  	  	                	<?= $book->borrower_type; ?>
								  	  	                </td>
								  	  	                <td>
								  	  	                	<?= ucfirst($book->reciever_lastname); ?><br>
								  	  	                	<?= ucfirst($book->reciever_type); ?>
								  	  	                </td>
								  	  	                <td><?= $book->date_borrowed; ?></td>
								  	  	                <td><?= $book->date_returned; ?></td>
								  	  	                <td><?= $book->return_status; ?></td>
								  	  	                <td><?= $book->fines; ?></td>
								  	  	            </tr>
								  	  	        	<?php endforeach; ?>

								  	  	        	<?php if($fetchReturnedBooks) : ?>
								  	  	            
								  	  	        	<tr>
								  	  	        		
								  	  	        		<td style="border-right: none !important; border-top: none !important; border-bottom: none !important;">
								  	  	        		</td>
								  	  	        		
								  	  	        		<td style="border: none !important;"></td>
								  	  	        		<td style="border: none !important;"></td>
								  	  	        		<td style="border: none !important;"></td>
								  	  	        		<td style="border: none !important;"></td>
								  	  	        		<td style="border: none !important;"></td>
								  	  	        		<td style="border-left: none !important; border-top: none !important; border-bottom: none !important; background-color: transparent;">
								  	  	        		</td>
								  	  	        		<td style="font-weight: bold;">
								  	  	        			Total Fines
								  	  	        		</td>
								  	  	        		<td style="padding-bottom: 20px !important; font-weight: bold;">
								  	  	        			<?php 
								  	  	        			$totalFines = View::totalFines();
								  	  	        			echo $totalFines->fines;
								  	  	        			?>
								  	  	        		</td>
								  	  	        		
								  	  	      
								  	  	        	</tr>

								  	  	        	<?php endif; ?>

								  	  	       		
								  	  	        </tbody>
								  	  	        <tfoot>
								  	  	            <tr>
								  	  	                <th>Accession</th>
								  	  	                <th>Category</th>
								  	  	                <th>Title</th>
								  	  	                <th>Returned by</th>
								  	  	                <th>Recieve by</th>
								  	  	                <th>Date Borrowed</th>
								  	  	                <th>Date Returned</th>
								  	  	                <th>Book Status</th>
								  	  	                <th>Fines</th>
								  	  	            
								  	  	            </tr>
								  	  	        </tfoot>
								  	  	        
								  	  	        
								  	  	    </table>

								  	  	    


						</div>

					</section>



					<?php require 'footer.php'; ?>

					