		<?php

			$fetchRules = View::fetchRules(['id' => 1]);


			// BORROW BOOK FORM
			if (isset($_POST['borrowBook'])) {
				
				$accession = $_POST['accession'];
				$title = $_POST['title'];
				$edition = $_POST['edition'];
				$borrowedcopies = $_POST['borrowedcopies'];
				$availablecopies = $_POST['availablecopies'];

				$academicYear = $_POST['academicYear'];
				$semester = $_POST['semester'];


				$countBorrowedBookCopies = View::countBorrowedBookCopies([
					'idnumber' => $_POST['idnumber'],
					'title' => $_POST['title'],
					'edition' => $_POST['edition']
				]);


				
				if(!isset($_POST['idnumber'])){

					$error = 1;

				} else {

					$countBorrowedBook = View::countBorrowedBook([
						'idnumber' => $_POST['idnumber']
					]);

	

					if($countBorrowedBook == $fetchRules->allowed_books){

						$error2 = 1;

					} else {

						
						if($countBorrowedBookCopies > 0){

								$error3 = 1;

						} else {

								$success = 1;

								$borrowSuccess = Controller::insertBorrowBook([
									'idnumber' => $_POST['idnumber'],
									'accession_id' => $accession,
									'title' => $title,
									'edition' => $edition,
									'borrowed_date' => date('Y-m-d'),
									'due_date' => date('Y-m-d', strtotime("+". $fetchRules->allowed_days ."days")),
									'academic_year' => $academicYear,
									'semester' => $semester
								]);


								$UpdateBook = Controller::UpdateBook([
									'borrowedcopies' => $borrowedcopies + 1,
									'availablecopies' => $availablecopies - 1
								], ['accession_id' => $accession]);

						}

					}
						

				}





			

			}



			// FETCH ALL BROADCAST BOOKS 
			$fetchBroadcastBooks = View::fetchBroadcastBooks([
				'broadcast' => 1
			]);


			// DISPLAY ALL BOOKS FOR CIRCULATION
			$fetchBooksCirculation = array_filter($fetchBroadcastBooks, function($circulation){
				return $circulation->type == 'Circulation';
			});

			// DISPLAY ALL BOOKS FOR RESERVED
			$fetchBooksReserved = array_filter($fetchBroadcastBooks, function($reserved){
				return $reserved->type == 'Reserved';
			});
		?>

		<?php require 'header.php'; ?>


					<section id="showcase">
						<!-- header -->
						<div class="content-header d-flex justify-content-between align-items-center container">
							<h3>BOOK AVAILABLE</h3>
						</div>	

						
						<div id="book-available" class="container mt-2">

							<ul class="nav nav-tabs third-tab pt-2" id="myTab" role="tablist">
								  <li class="nav-item" role="presentation">
								    <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#bookavailable-circulation" type="button" role="tab" aria-controls="home" aria-selected="true">CIRCULATION</button>
								  </li>
								  
								  <li class="nav-item" role="presentation">
								    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#bookavailable-reserved" type="button" role="tab" aria-controls="profile" aria-selected="false">RESERVED</button>
								  </li>
								
							</ul>

							<div class="tab-content pt-2" id="myTabContent">

								  	  <div class="tab-pane fade show active bg-light text-dark text-center" id="bookavailable-circulation">


								  	  	<table id="available-circulation" class="table table-striped mt-3" style="width:100%">
								  	  	        <thead>
								  	  	            <tr>
								  	  	                <th>Accession</th>
								  	  	                <th>Category</th>
								  	  	                <th>Title</th>
								  	  	                <th>DDC</th>
								  	  	                <th>Author</th>
								  	  	                <!-- <th>Total Copies</th>
								  	  	                <th>Borrowed Copies</th>
								  	  	                <th>Available Copies</th> -->
								  	  	                <th><i class="fas fa-cog"></i></th>
								  	  	            </tr>
								  	  	        </thead>
								  	  	        <tbody id="book-info">
								  	  	        	<?php foreach($fetchBooksCirculation as $book) : ?>
								  	  	            <tr>
								  	  	                <td><?= $book->accession_id; ?></td>
								  	  	                <td><?= $book->category_name;?></td>
								  	  	                <td><?= $book->title; ?></td>
								  	  	                <td><?= $book->ddc ?></td>
								  	  	                <td><?= $book->author; ?></td>
									  	  	            
								  	  	                <td>
									  	  	                <div class="d-flex flex-row align-items-center justify-content-center ">

										  	  	                <button data-bs-toggle="modal" data-bs-target="#circulationView" value="<?= $book->accession_id; ?>" class="button-icon fas fa-desktop" title="view" id="circulationBookModal"  style="border:none; outline-style: none;background-color: transparent;">
								  	  	               			 </button>

								  	  	               			 <?php if($book->availablecopies < 1) : ?>

										  	  	                <button style="width: 110px;" data-bs-toggle="modal" data-bs-target="#addBorrowersModal" class="btn btn-primary btn-sm" id="borrowBook" value="<?= $book->accession_id; ?>" disabled>
										  	  	                	Borrowed	
										  	  	                </button>

										  	  	                 <?php elseif($book->status === 'For purchased') : ?>

										  	  	                 <button style="width: 110px;" data-bs-toggle="modal" data-bs-target="#addBorrowersModal" class="btn btn-primary btn-sm" id="borrowBook" value="<?= $book->accession_id; ?>" disabled>
										  	  	                	For Purchased	
										  	  	                </button>

										  	  	            	<?php else : ?>

										  	  	            		<button style="width: 110px;" data-bs-toggle="modal" data-bs-target="#addBorrowersModal" class="btn btn-primary btn-sm" id="borrowBook" value="<?= $book->accession_id; ?>">
										  	  	            			Borrow	
										  	  	            		</button>

										  	  	            	<?php endif; ?>

										  	  	           	 </div>
								  	  	            	</td>
								  	  	            </tr>
								  	  	           <?php endforeach; ?>
								  	  	        </tbody>
								  	  	        <tfoot>
								  	  	            <tr>
								  	  	                <th>Accession</th>
								  	  	                <th>Category</th>
								  	  	                <th>Title</th>
								  	  	                <th>DDC</th>
								  	  	                <th>Author</th>
								  	  	                <!-- <th>Total Copies</th>
								  	  	                <th>Borrowed Copies</th>
								  	  	                <th>Available Copies</th> -->
								  	  	                <th><i class="fas fa-cog"></i></th>
								  	  	            </tr>
								  	  	        </tfoot>
								  	  	    </table>

								  	  	    <!-- modal for view single book in circulation books tab panel -->
								  	  	    <?php require 'modals/view/circulationbookmodal.php'; ?>
								  	  	    <!-- End for view single book modal in circulation books tab panel -->

								  	  </div>

							  	    	  <div class="tab-pane fade show bg-light text-dark text-center" id="bookavailable-reserved">


							  	    	  	<table id="available-reserved" class="table table-striped mt-3" style="width:100%">
							  	    	  	        <thead>
							  	    	  	            <tr>
							  	    	  	                <th>Accession</th>
							  	    	  	                <th>Category</th>
							  	    	  	                <th>Title</th>
							  	    	  	                <th>DDC</th>
							  	    	  	                <th>Author</th>
							  	    	  	                <!-- <th>Total Copies</th>
							  	    	  	                <th>Borrowed Copies</th>
							  	    	  	                <th>Available Copies</th> -->
							  	    	  	               <th><i class="fas fa-cog"></i></th>
							  	    	  	            </tr>
							  	    	  	        </thead>
							  	    	  	        <tbody id="book-info">
							  	    	  	        	<?php foreach($fetchBooksReserved as $book) : ?>
							  	    	  	            <tr>
							  	    	  	                <td><?= $book->accession_id; ?></td>
							  	    	  	                <td><?= $book->category_name;?></td>
							  	    	  	                <td><?= $book->title; ?></td>
							  	    	  	                <td><?= $book->ddc ?></td>
							  	    	  	                <td><?= $book->author; ?></td>
							  	    	  	                
							  	    	  	                <td>			

							  	    	  	                	<div class="d-flex flex-row align-items-center justify-content-center "> 	                	
			  	  	  	  	                  	  	                <button data-bs-toggle="modal" data-bs-target="#reservedView" value="<?= $book->accession_id; ?>" class="button-icon fas fa-desktop" title="view" id="reservedBookModal"  style="border:none;
			  	  	  	  	                	               		outline-style: none;background-color: transparent;">
			  	  	  	  	                  	  	                </button>

									  	  	  	  	             <?php if($book->availablecopies < 1) : ?>

										  	  	                <button style="width: 110px;" data-bs-toggle="modal" data-bs-target="#addBorrowersModal" class="btn btn-primary btn-sm" id="borrowBook" value="<?= $book->accession_id; ?>" disabled>
										  	  	                	Borrowed	
										  	  	                </button>

										  	  	                 <?php elseif($book->status === 'For purchased') : ?>

										  	  	                 <button style="width: 110px;" data-bs-toggle="modal" data-bs-target="#addBorrowersModal" class="btn btn-primary btn-sm" id="borrowBook" value="<?= $book->accession_id; ?>" disabled>
										  	  	                	For Purchased	
										  	  	                </button>

										  	  	            	<?php else : ?>

										  	  	            		<button style="width: 110px;" data-bs-toggle="modal" data-bs-target="#addBorrowersModal" class="btn btn-primary btn-sm" id="borrowBook" value="<?= $book->accession_id; ?>">
										  	  	            			Borrow	
										  	  	            		</button>

										  	  	            	<?php endif; ?>

									  	  	  	  	                
								  	  	  	  	            	</div>

							  	    	  	            	</td>

							  	    	  	            </tr>
							  	    	  	           <?php endforeach; ?>
							  	    	  	        </tbody>
							  	    	  	        <tfoot>
							  	    	  	            <tr>
							  	    	  	                <th>Accession</th>
							  	    	  	                <th>Category</th>
							  	    	  	                <th>Title</th>
							  	    	  	                <th>DDC</th>
							  	    	  	                <th>Author</th>
							  	    	  	                <!-- <th>Total Copies</th>
							  	    	  	                <th>Borrowed Copies</th>
							  	    	  	                <th>Available Copies</th> -->
							  	    	  	                <th><i class="fas fa-cog"></i></th>	
							  	    	  	            </tr>
							  	    	  	        </tfoot>
							  	    	  	    </table>

							  	    	  	    <!-- modal for view single book in reserved books tab panel -->
							  	    	  	    <?php require 'modals/view/reservedbookmodal.php'; ?>
							  	    	  	    <!-- End for view single book in reserved books tab panel -->

							  	    	  </div>

							  	    	 <?php require 'modals/add/addborrowersmodal.php'; ?>

							</div>	
						</div>

					</section>



					<?php require 'footer.php'; ?>

					<script>
						
						<?php if(isset($error)) : ?>
							alert('Error: No Borrower Found!');
						<?php endif; ?>

						<?php if(isset($error2)) : ?>
							alert('Error: Borrower already exceeds the borrowed book limit!');
						<?php endif; ?>

						<?php if(isset($error3)) : ?>
							alert('Error: Borrower already borrowed this book!');
						<?php endif; ?>

						<?php if(isset($success)) : ?>
							alert('Borrow Book Successful!');
						<?php endif; ?>

					</script>