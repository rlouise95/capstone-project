<?php 


	// $number = 2;

	// echo date('Y-m-d', strtotime("+5days"));

	// exit();

	$fetchBorrowedBooks = View::fetchBorrowedBooks();

	// var_dump($fetchBorrowedBooks); exit();




	// echo '<pre>';
	// var_dump($fetchBorrowedBooks); exit();
	// echo '</pre>';



?>

		<?php require 'header.php'; ?>


					<section id="showcase">
						<!-- header -->
						<div class="content-header d-flex justify-content-between align-items-center container">
							<h3>BOOK BORROWED</h3>
						</div>	

						
						<div id="book-borrowed" class="container mt-5 text-center">

							<table id="student-table" class="table table-striped mt-3" style="width:100%">

						        <thead>
						           <tr>
						               <th>Accession #</th>
						               <th>Category</th>
						               <th>Title</th>
						               <th>Author</th>
						               <th>Borrowed copies</th>
						              <th><i class="fas fa-cog"></i></th>
						           </tr>
						        </thead>
						        <tbody>
						        <?php foreach($fetchBorrowedBooks as $borrowed) : ?>
						          <tr>
						              <td><?= $borrowed->accession_id; ?></td>
						              <td><?= $borrowed->category_name; ?></td>
						              <td><?= $borrowed->title; ?></td>
						              <td><?= $borrowed->author; ?></td>
						              <td><?= $borrowed->borrowedcopies; ?></td>
					
						              
						              <td class="table-icon button-icon">

						              	<button data-bs-toggle="modal" id="viewBookBorrowers" value="<?= $borrowed->accession_id; ?>" data-bs-target="#viewBorrowers" class="fas fa-desktop" title="View Borrowers" style="border:none; 
							             outline-style: none;background-color:transparent;">
						              	</button>
						              </td>
						          </tr>
						    	<?php endforeach; ?>
						        </tbody>
						        <tfoot>
						           <tr>
						               <th>Accession #</th>
						               <th>Category</th>
						               <th>Title</th>
						               <th>Author</th>
						               <th>Borrowed copies</th>
						               <th><i class="fas fa-cog"></i></th>
						           </tr>
						        </tfoot>
						    
					   		 </table>	
								

								 <?php require 'modals/view/viewborrowersmodal.php'; ?>
						</div>

					</section>



					<?php require 'footer.php'; ?>