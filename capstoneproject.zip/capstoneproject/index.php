<?php 
	session_start();
	require 'classes/class.model.php';
	require 'classes/class.view.php';
	require 'classes/class.controller.php';
	require 'classes/class.router.php';

	$uri = $_GET['uri'];

	Router::routes($uri);