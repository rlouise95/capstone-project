const tl = gsap.timeline({default: {ease:'power1'}});


tl.to('span', {y:'0%',stagger:0.1,duration:1});

tl.to('.intro-text', {opacity:'0',duration:0.6});

tl.to('.loader-img', {opacity:'0',duration:1},'-=1');


tl.fromTo('.slider', {y:'100%'},
	{y:'-100%',duration:1});

tl.to('.loader',{y:'-100%',duration:1},'-=1');

tl.fromTo('nav', {opacity:'0'},
	{opacity:'1',duration:1});

tl.fromTo('.shelves', {opacity:'0'},
	{opacity:'1',duration:1});

tl.fromTo('.shelve', {opacity:'0'},
	{opacity:'1',duration:1});


 tl.fromTo('.book', {opacity:'0',y:'-10%'},
  {opacity:'1',y:'0%',stagger:0.1, duration:1},'-=1');


 // SINGLE PAGE

 const tl2 = gsap.timeline({default: {ease:'power1'}});


 tl2.to('.sp-wrapper',{opacity:'1',duration:1});

 tl2.to('.bg-slider',{x:'0%',duration:1});

 tl2.fromTo('.type-text',{height:'0%'},
 	{height:'auto',duration:1},'-=1');
 tl2.fromTo('.block',{opacity:'0'},{opacity:'1',duration:1});
 tl2.fromTo('.display',{opacity:'0'},
 	{opacity:'1',duration:1},'-=1');



// LOAD BOOKS FROM SERVER

$('#circulation').load('server/opac/circulationcategory.php');
$('#reserved').load('server/opac/reservedcategory.php');


// SELECT CATEGORY

$('#select-category').change((e) => {

	const category = $(e.target).val();

		if(category != 'All'){

			$.ajax({
				url: 'server/opac/selectcategory.php',
				method: 'POST',
				data: {
					category: category, type: 'Circulation'
				}, success: function(data) {
					$('#circulation').html(data);
				}
			});

			$.ajax({
				url: 'server/opac/selectcategory.php',
				method: 'POST',
				data: {
					category: category, type: 'Reserved'
				}, success: function(data) {
					$('#reserved').html(data);
				}
			});


		} else {

			$('#circulation').load('server/opac/circulationcategory.php');
			$('#reserved').load('server/opac/reservedcategory.php');

		}

});



// SEARCH BOOK

$('#search-input').keyup((e) => {

	const category = $('#select-category').val();
	const filterkey = $('#select-key').val();
	const searchkey = $(e.target).val();

		if(searchkey != ''){

			$.ajax({
				url: 'server/opac/searchbookcirculation.php',
				method: 'POST',
				data: {
					category: category, filterkey: filterkey, searchkey: searchkey, type: 'Circulation'
				}, success: function(data) {
					$('#circulation').html(data);
				}
			});

			$.ajax({
				url: 'server/opac/searchbookreserved.php',
				method: 'POST',
				data: {
					category: category, filterkey: filterkey, searchkey: searchkey, type: 'Reserved'
				}, success: function(data) {
					$('#reserved').html(data);
				}
			});

	} else {


			if(category != 'All'){

				$.ajax({
					url: 'server/opac/selectcategory.php',
					method: 'POST',
					data: {
						category: category, type: 'Circulation'
					}, success: function(data) {
						$('#circulation').html(data);
					}
				});

				$.ajax({
					url: 'server/opac/selectcategory.php',
					method: 'POST',
					data: {
						category: category, type: 'Reserved'
					}, success: function(data) {
						$('#reserved').html(data);
					}
				});


			} else {

				$('#circulation').load('server/opac/circulationcategory.php');
				$('#reserved').load('server/opac/reservedcategory.php');

			}

		

	}


});








