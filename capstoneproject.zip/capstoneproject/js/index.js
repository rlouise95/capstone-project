
// search engine
$(document).ready(function() {
   $('#category-tables').DataTable();
   $('#publisher-tables').DataTable();
   $('#department-tables').DataTable();

    $('#book-tables').DataTable({
      "order": [[ 7, "desc" ]]
    });
    $('#circulation-tables').DataTable({
      "order": [[ 7, "desc" ]]
    });
    $('#reserved-tables').DataTable({
      "order": [[ 7, "desc" ]]
    });
    $('#student-table').DataTable();
    $('#available-circulation').DataTable({
      "order": [[ 0, "desc" ]]
    });
    $('#user-tables').DataTable({
      "order": [[ 0, "asc" ]]
    });
    $('#available-reserved').DataTable({
      "order": [[ 0, "desc" ]]
    });
    $('#returned-book').DataTable({
        dom: 'Bfrtip',
        buttons: [
            {
                            extend: 'print',
                            customize: function ( win ) {
                                $(win.document.body)
                                    .css( 'font-size', '10pt' )
                                    .prepend(
                                        '<img src="http://localhost/capstoneproject/images/logo.png" style=" width: 100px; position:relative; left: 50%; transform: translateX(-50%);" />'
                                    );
             
                                $(win.document.body).find( 'table' )
                                    .addClass( 'compact' )
                                    .css( 'font-size', 'inherit' );
                            }
                        }
        ],

        "order": [[ 6, "desc" ]]
    });
   



    // set localstorage for parent tabs panel
    $('.first-tab button').on('show.bs.tab', function(e) {
         localStorage.setItem('activeTab', $(e.target).attr('data-bs-target'));
     });

     const activeTab = localStorage.getItem('activeTab');

    if(activeTab){
      $('.first-tab button[data-bs-target="' + activeTab + '"]').tab('show');
    }
     // end set localstorage for parent tabs panel


     // set localstorage for children tabs panel
     $('.second-tab button').on('show.bs.tab', function(e) {
          localStorage.setItem('activeTab2', $(e.target).attr('data-bs-target'));
      });

      const activeTab2 = localStorage.getItem('activeTab2');

     if(activeTab2){
       $('.second-tab button[data-bs-target="' + activeTab2 + '"]').tab('show');
     }
      // end set localstorage for children tabs panel

});





//animate 
const tl = gsap.timeline({defaults: {ease: "power1"}});


	//dashboard animate card

  tl.to("#showcase", {display:"block", duration:0.6});

	tl.fromTo(".card",{opacity:"0",y:"-30%"},
		{opacity:"1", y:"0%", duration:1, stagger:0.10, ease:"back"});

	//maintaenance
	tl.fromTo("#maintenance",{opacity:"0"},
	 {opacity:"1", duration:0.8},'-=1');

  //student
  tl.fromTo("#student",{opacity:"0"},{opacity:"1", duration:0.8},"-=1");

  //teacher
   tl.fromTo("#teacher",{opacity:"0"},{opacity:"1", duration:0.8},"-=1");

  //book available
   tl.fromTo("#book-available",{opacity:"0"},{opacity:"1", duration:0.8},"-=1");

 //   //book borrowed
   tl.fromTo("#book-borrowed",{opacity:"0"},{opacity:"1", duration:0.8},"-=1");
   //book returned
    tl.fromTo("#book-returned",{opacity:"0"},{opacity:"1", duration:0.8},"-=1");






    // ajaxs
		
	$(document).ready(function(){

		// ajax call for category update

		$('[id="updateCategory"]').click((e) => {

			var id = e.target.value;

			 $.ajax({
              url: 'server/category/update.php',
              method: 'POST',
              data: {
                  id: id
              },
              success: function(data){
                $('.category-body').html(data);
              }
            });
		});

    // ajax call for category delete

    $('[id="deleteCategory"]').click((e) => {

      var id = e.target.value;

      if(confirm('Are you sure you want to delete this category?')){

        $.ajax({
                 url: 'server/category/delete.php',
                 method: 'POST',
                 data: {
                     id: id
                 },success: function(data) {
                   window.location.href = 'admin-maintenance';
                 }
             });

      }

    });


    // ajax call for publisher update

    $('[id="updatePublisher"]').click((e) => {

      var id = e.target.value;

       $.ajax({
              url: 'server/publisher/update.php',
              method: 'POST',
              data: {
                  id: id
              },
              success: function(data){
                $('.publisher-body').html(data);
              }
            });
    });



    // ajax call for publisher delete

    $('[id="deletePublisher"]').click((e) => {

      var id = e.target.value;

      if(confirm('Are you sure you want to delete this publisher?')){

        $.ajax({
                 url: 'server/publisher/delete.php',
                 method: 'POST',
                 data: {
                     id: id
                 },success: function(data) {
                   window.location.href = 'admin-maintenance';
                 }
             });

      }

    });




    // ajax call for department update

    $('[id="updateDepartment"]').click((e) => {

      var id = e.target.value;

       $.ajax({
              url: 'server/department/update.php',
              method: 'POST',
              data: {
                  id: id
              },
              success: function(data){
                $('.department-body').html(data);
              }
            });
    });



    // ajax call for publisher delete

    $('[id="deleteDepartment"]').click((e) => {

      var id = e.target.value;

      if(confirm('Are you sure you want to delete this department?')){

        $.ajax({
                 url: 'server/department/delete.php',
                 method: 'POST',
                 data: {
                     id: id
                 },success: function(data) {
                   window.location.href = 'admin-maintenance';
                 }
             });

      }

    });




    // ajax call for add book

    $('#addBook').submit((e) => {

        e.preventDefault();

        const accession = $('.accession').val();
        const category = $('.category').val();
        const ddc = $('.ddc').val();
        const author = $('.author').val();
        const title = $('.title').val();
        const edition = $('.edition').val();
        const placeofpublication = $('.placeofpublication').val();
        const publisher = $('.publisher').val();
        const copyrightdate = $('.copyrightdate').val();
        // const copies = $('.copies').val();
        const status = $('.status').val();
        const type = $('.type').val();
        const image = $('.image');

        const data = new FormData();

        jQuery.each(jQuery('.image')[0].files, function(i, file) {
            data.append('file-'+i, file);
        });

        data.append('accession', accession);
        data.append('category', category);
        data.append('ddc', ddc);
        data.append('author', author);
        data.append('title', title);
        data.append('edition', edition);
        data.append('placeofpublication', placeofpublication);
        data.append('publisher', publisher);
        data.append('copyrightdate', copyrightdate);
        // data.append('copies', copies);
        data.append('status', status);
        data.append('type', type);

          $.ajax({
             url: 'server/book/add.php',
             method: 'POST',
             cache: false,
              contentType: false,
              processData: false,
             data: data ,
             success: function(data) {
              $('.book-body').html(data);
             }
         });

      });



    $('[id="bookCopy"]').click((e) => {

        const accession =  e.target.value;

         $.ajax({
            url: 'server/book/addbookcopyform.php',
            method: 'POST',
            data: {accession: accession},
            success: function(data) {
             $('.book-copy').html(data);
            }
        });
      });




    $('[id="addBookCopy"]').submit((e) => {

        e.preventDefault();



        const accession = e.target[0].value;
        const ddc = e.target[1].value;
        const author = e.target[2].value;
        const title = e.target[3].value;
        const edition = e.target[4].value;
        const placeofpublication = e.target[5].value;
        // const copies = e.target[6].value;
         const publisher = e.target[6].value;
        const category = e.target[7].value;
        const copyrightdate = e.target[8].value;
        const status = e.target[9].value;
        const type = e.target[10].value;

        const image = e.target[11];
        
        

        const data = new FormData();

        jQuery.each(jQuery(image)[0].files, function(i, file) {
            data.append('file-'+i, file);
        });

        data.append('accession', accession);
        data.append('category', category);
        data.append('ddc', ddc);
        data.append('author', author);
        data.append('title', title);
        data.append('edition', edition);
        data.append('placeofpublication', placeofpublication);
        data.append('publisher', publisher);
        data.append('copyrightdate', copyrightdate);
        // data.append('copies', copies);
        data.append('status', status);
        data.append('type', type);

          $.ajax({
             url: 'server/book/addcopy.php',
             method: 'POST',
             cache: false,
              contentType: false,
              processData: false,
             data: data ,
             success: function(data) {
              $('.book-copy').html(data);
             }
         });

      });





      // ajax call for view single book modal in all book tab panel

    $('[id="allBookModal"]').click((e) => {

        const accession =  e.target.value;

         $.ajax({
            url: 'server/book/viewbook.php',
            method: 'POST',
            data: {accession: accession},
            success: function(data) {
             console.log(data);
             $('.allBookModal').html(data);
            }
        });
      });

    // ajax call for view single book modal in circulation book tab panel

    $('[id="circulationBookModal"]').click((e) => {

        const accession =  e.target.value;

         $.ajax({
            url: 'server/book/viewbook.php',
            method: 'POST',
            data: {accession: accession},
            success: function(data) {
             console.log(data);
             $('.circulationBookModal').html(data);
            }
        });
      });

    // ajax call for view single book modal in reserved book tab panel

    $('[id="reservedBookModal"]').click((e) => {

        const accession =  e.target.value;

         $.ajax({
            url: 'server/book/viewbook.php',
            method: 'POST',
            data: {accession: accession},
            success: function(data) {
             console.log(data);
             $('.reservedBookModal').html(data);
            }
        });
      });


    // ajax call for edit single book modal in all book tab panel

    $('[id="editAllBookModal"]').click((e) => {

        const accession =  e.target.value;

         $.ajax({
            url: 'server/book/editform.php',
            method: 'POST',
            data: {accession: accession},
            success: function(data) {
             $('.editAllBookModal').html(data);
            }
        });
      });

    // ajax call for edit single book modal in circulation book tab panel

    $('[id="editCirculationBookModal"]').click((e) => {

        const accession =  e.target.value;

         $.ajax({
            url: 'server/book/editform.php',
            method: 'POST',
            data: {accession: accession},
            success: function(data) {
             console.log(data);
             $('.editCirculationBookModal').html(data);
            }
        });
      });

     // ajax call for edit single book modal in reserved book tab panel

    $('[id="editReservedBookModal"]').click((e) => {

        const accession =  e.target.value;

         $.ajax({
            url: 'server/book/editform.php',
            method: 'POST',
            data: {accession: accession},
            success: function(data) {
             console.log(data);
             $('.editReservedBookModal').html(data);
            }
        });
      });

    // ajax call for edit book

    $('[id="editBook"]').submit((e) => {

        e.preventDefault();

        console.log(e.target[0].value);


        const accession = e.target[0].value;
        const ddc = e.target[1].value;
        const author = e.target[2].value;
        const title = e.target[3].value;
        const edition = e.target[4].value;
        const placeofpublication = e.target[5].value;
        // const copies = e.target[6].value;
         const publisher = e.target[6].value;
        const category = e.target[7].value;
        const copyrightdate = e.target[8].value;
        const status = e.target[9].value;
        const type = e.target[10].value;

        const image = e.target[11];
        const latestbookimage = e.target[12].value;
        const borrowedcopies = e.target[13].value;
        

        const data = new FormData();

        jQuery.each(jQuery(image)[0].files, function(i, file) {
            data.append('file-'+i, file);
        });

        data.append('accession', accession);
        data.append('category', category);
        data.append('ddc', ddc);
        data.append('author', author);
        data.append('title', title);
        data.append('edition', edition);
        data.append('placeofpublication', placeofpublication);
        data.append('publisher', publisher);
        data.append('copyrightdate', copyrightdate);
        // data.append('copies', copies);
        data.append('status', status);
        data.append('type', type);
        data.append('latestbookimage', latestbookimage);
        data.append('latestborrowedcopies', borrowedcopies);

          $.ajax({
             url: 'server/book/edit.php',
             method: 'POST',
             cache: false,
              contentType: false,
              processData: false,
             data: data ,
             success: function(data) {
              const currentModalForm = '.'+$(e.target).children().attr('class').split(' ').pop();
              $(`${currentModalForm}`).html(data);
             }

             

         });

      });

    // ajax call for delete books

    $('[id="deleteBook"]').click((e) => {

      const accession = $(e.target).val();

      if(confirm('are you sure you want to delete this book?')){

        $.ajax({
          url: 'server/book/delete.php',
          method: 'POST',
          data: {
            accession: accession
          }, success: function(data) {
             window.location.href = 'admin-maintenance';
           }
        });

      }

    });


    // ajax call for broadcast books

    $('[id="broadcast"]').click((e) => {

      const accession = $(e.target).val();

      if(confirm('are you sure you want to broadcast this book?')){

        $.ajax({
          url: 'server/book/broadcast.php',
          method: 'POST',
          data: {
            accession: accession
          }, success: function(data) {
             window.location.href = 'admin-maintenance';
           }
        });

      }

    });


    // ajax call for Unbroadcast books

    $('[id="unbroadcast"]').click((e) => {

      const accession = $(e.target).val();

      if(confirm('are you sure you want to Unbroadcast this book?')){

        $.ajax({
          url: 'server/book/unbroadcast.php',
          method: 'POST',
          data: {
            accession: accession
          }, success: function(data) {
             window.location.href = 'admin-maintenance';
           }
        });

      }

    });




    // ajax call for add users

    $('#addUser').submit((e) => {

      e.preventDefault();

      $lastname = e.target[0].value;
      $firstname = e.target[1].value;
      $middlename = e.target[2].value;
      $type = e.target[3].value;
      $contactnumber = e.target[4].value;
      $username = e.target[5].value;
      $password = e.target[6].value;
      $securityquestion = e.target[7].value;
      $securityanswer = e.target[8].value;

      $.ajax({
          url: 'server/user/add.php',
          method: 'POST',
          data: {
            lastname: $lastname, firstname: $firstname, middlename: $middlename, type: $type, contactnumber: $contactnumber, username: $username, password: $password, securityquestion: $securityquestion, securityanswer: $securityanswer
          }, success: function(data) {
            $('.user-body').html(data);
           }
        });


    });


    // ajax call for edit users

    $('[id="updateUser"]').click((e) => {

      const id = $(e.target).val();


      $.ajax({
          url: 'server/user/editform.php',
          method: 'POST',
          data: {
              id: id
          }, success: function(data) {
            $('.editUserForm').html(data);
           }
        });


    });




    // ajax call for delete user

    $('[id="deleteUser"]').click((e) => {

      const user_id = $(e.target).val();
    
      if(confirm('are you sure you want to delete this user?')){

        $.ajax({
          url: 'server/user/delete.php',
          method: 'POST',
          data: {
            user_id: user_id
          }, success: function(data) {
              window.location.href = 'admin-maintenance';
           }
        });

      }

    });




    // ajax call for change rules

    $('[id="changeRules"]').submit((e) => {

      e.preventDefault();

      if(confirm('are you sure you want to change business rules?')){

        $.ajax({
          url: 'server/rules/update.php',
          method: 'POST',
          data: {
            
          }, success: function(data) {
            $('.rules').html(data);
           }
        });

      }

    });




    // ajax call for view borrowers history

    $('[id="viewBorrowerHistory"]').click((e) => {

      const idnumber = $(e.target).val();

        $.ajax({
          url: 'server/borrower/history.php',
          method: 'POST',
          data: {
            idnumber: idnumber
          }, success: function(data) {

            $('.viewBorrowerHistory').html(data);

           }
        });

    });




    // ajax call for edit borrowers

    $('[id="editBorrower"]').click((e) => {

      const idnumber = $(e.target).val();

        $.ajax({
          url: 'server/borrower/editform.php',
          method: 'POST',
          data: {
            idnumber: idnumber
          }, success: function(data) {

            $('.editBorrowerModal').html(data);

           }
        });

    });




    // ajax call for delete borrowers

    $('[id="deleteBorrower"]').click((e) => {

      const idnumber = $(e.target).val();
     
      const borrowerType = $(e.target).children().val();

      if(confirm('are you sure you want to delete this borrower?')){

        $.ajax({
          url: 'server/borrower/delete.php',
          method: 'POST',
          data: {
            idnumber: idnumber
          }, success: function(data) {

              if(borrowerType == 'Student'){
                window.location.href = 'admin-student';
              }

              if(borrowerType == 'Teacher'){
                window.location.href = 'admin-teacher';
              }

           }
        });

      }

    });



    // ajax call for delete borrowers

    $('[id="borrowBook"]').click((e) => {

      const accession = $(e.target).val();

        $.ajax({
          url: 'server/borrow/borrowinfo.php',
          method: 'POST',
          data: {
            accession: accession
          }, success: function(data) {
            $('.borrow-body').html(data);
           }
        });


    });

    // ajax call for view book borrowers

    $('[id="viewBookBorrowers"]').click((e) => {

      const accession = $(e.target).val();

        $.ajax({
          url: 'server/bookborrowed/view.php',
          method: 'POST',
          data: {
            accession: accession
          }, success: function(data) {
            $('.viewBorrowersModal').html(data);
           }
        });


    });


    //  ADD BULK OF BORROWERS

    $('[id="import_excel_form"]').submit((e) => {

        e.preventDefault();

        const image = e.target[0];


         const data = new FormData();

        jQuery.each(jQuery(image)[0].files, function(i, file) {
            data.append('file-'+i, file);
        });

        console.log(data);

        data.append('excel', image);

         $.ajax({
             url: 'server/borrower/addbulkborrowers.php',
             method: 'POST',
             cache: false,
              contentType: false,
              processData: false,
             data: data ,
             success: function(data) {
              $('#fileMessage').html(data);
              console.log(data);
              if(data === 'Import Successfully!'){
                $('#fileMessage').attr('class', 'my-auto p-3');
                $('#fileMessage').parent().attr('class', 'mx-auto text-success border border-success mb-4');
              }
             }
         });


    });


	});




  
  // setTimeout(function(){
  //   document.getElementById('showcase').style.display = 'block';
  // }, 300);
  

