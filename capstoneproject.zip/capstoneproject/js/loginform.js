
const tl = gsap.timeline({defaults: {ease: "power1"}});

tl.fromTo(".form-container", {opacity:"0"}, {opacity:"1", duration:1});
tl.fromTo(".r-color", {y:"-100%"}, {y:"0%", duration:1});
tl.fromTo(".logo-form", {y:"-100%"}, {y:"0%", duration:1});
tl.fromTo(".cec-logo", {opacity:"0"},
 {opacity:"1", duration:1});
tl.fromTo("form", {opacity:"0", x:"-20%"},{opacity:"1", x:"0%",duration:1}, "-=1");



$(document).ready(function(){

	$('#login').submit((e) => {

		e.preventDefault();

		const uname = $('.loginUsername').val();
		const pword = $('.loginPassword').val();

		$.ajax({
			url: 'server/login.php',
			method: 'POST',
			data: {
				username: uname, password: pword
				}, success: data => {
					$('#loginform-inputs').html(data);	
					console.log(data);
				}
			});

	});



	$('#changePassword').click(() => {

		const uname = $('.loginUsername').val();

		$.ajax({
			url: 'server/forgotpasswordform.php',
			method: 'POST',
			data: {
				username: uname
				}, success: data => {
					$('.forgotPassword').html(data);	
					console.log(data);
				}
			});

	});

	$('#submitNewPassword').submit((e) => {
		e.preventDefault();

		const uname = e.target[0].value
		const answer = e.target[2].value
		const newpassword = e.target[3].value
		const confirmpassword = e.target[4].value
		const newquestion = e.target[5].value
		const newanswer = e.target[6].value

		$.ajax({
			url: 'server/forgotpassword.php',
			method: 'POST',
			data: {
				username: uname, answer: answer, newpassword: newpassword, confirmpassword: confirmpassword, newquestion: newquestion, newanswer: newanswer
				}, success: data => {
					$('.forgotPassword').html(data);	
					console.log(data);
				}
			});

	});


});