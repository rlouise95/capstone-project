<?php 

	class View extends Model {

		
		private static $table = [
			'users', 'categories', 'books', 'department', 'borrowers', 'book_borrowed', 'publishers', 'rules', 'book_returned'
		];


		// TOTAL
		public static function totalFines(){
			return parent::addAll(self::$table[8]);
		}


		// COUNT
		public static function countAllCategories()
		{
			return parent::countAll(self::$table[1]);
		}

		public static function countAllPublishers()
		{
			return parent::countAll(self::$table[6]);
		}

		public static function countAllDepartments()
		{
			return parent::countAll(self::$table[3]);
		}

		public static function countAllBooks()
		{
			return parent::countAll(self::$table[2]);
		}

		public static function countAllUsers()
		{
			return parent::countAll(self::$table[0]);
		}

		public static function countBookBorrowed()
		{
			return parent::countAll(self::$table[5]);
		}





		// COUNT WHERE IF EXIST
		public static function countAllTeachers($data)
		{
			return parent::count($data, self::$table[4]);
		}
		public static function countAllStudents($data)
		{
			return parent::count($data, self::$table[4]);
		}
		public static function countUser($data)
		{
			return parent::count($data, self::$table[0]);
		}

		public static function countCategory($data)
		{
			return parent::count($data, self::$table[1]);
		}

		public static function countPublisher($data)
		{
			return parent::count($data, self::$table[6]);
		}

		public static function countDepartment($data)
		{
			return parent::count($data, self::$table[3]);
		}

		public static function countBook($data)
		{
			return parent::count($data, self::$table[2]);
		}

		public static function countBorrower($data)
		{
			return parent::count($data, self::$table[4]);
		}

		public static function countBookAvailable($data)
		{
			return parent::count($data, self::$table[2]);
		}

		public static function countLostBook($data)
		{
			return parent::count($data, self::$table[8]);
		}

		public static function countDamagedBook($data)
		{
			return parent::count($data, self::$table[8]);
		}



		public static function countBorrowedBook($data)
		{
			return parent::count($data, self::$table[5]);
		}

		public static function countBorrowedBookCopies($data)
		{
			return parent::count($data, self::$table[5]);
		}







		// COUNT WHERE IF EXIST WITH JOIN

		public static function countBookCategory($data)
		{
			return parent::countJoinWhere($data, self::$table[2], self::$table[1], 'category_id');
		}

		public static function countBookPublisher($data)
		{
			return parent::countJoinWhere($data, self::$table[2], self::$table[6], 'publisher_id');
		}

		public static function countBookDepartment($data)
		{
			return parent::countJoinWhere($data, self::$table[4], self::$table[3], 'department_id');
		}




		// FETCH ALL
		public static function fetchCategories() 
		{
			return parent::fetch(self::$table[1], 'category_id');
		}

		public static function fetchPublishers() 
		{
			return parent::fetch(self::$table[6], 'publisher_id');
		}

		public static function fetchDepartments() 
		{
			return parent::fetch(self::$table[3], 'department_id');
		}

		public static function fetchUsers() 
		{
			return parent::fetch(self::$table[0], 'user_id');
		}


		public static function fetchReturnedBooks() 
		{
			return parent::fetch(self::$table[8], 'id');
		}






		// FETCH ALL WITH JOIN TABLE
		public static function fetchBooks() 
		{
			return parent::fetchtwojoin(self::$table[2], self::$table[1], self::$table[6], 'category_id', 'publisher_id', 'date_added');
		}

		public static function fetchBorrowedBooks() 
		{
			return parent::fetchAllDistinctjoin(self::$table[5], self::$table[2], self::$table[1], 'accession_id', 'category_id', 'id');
		}

		public static function fetchBorrowers() 
		{
			return parent::fetchjoin(self::$table[4], self::$table[3], 'department_id', 'lastname');
		}



		// FETCH WHERE
		public static function fetchRules($data)
		{
			return parent::fetchWhere($data, self::$table[7]);
		}
		public static function fetchUser($data)
		{
			return parent::fetchWhere($data, self::$table[0]);
		}

		public static function fetchSingleCategory($data) 
		{
			return parent::fetchWhere($data, self::$table[1]);
		}

		public static function fetchSinglePublisher($data) 
		{
			return parent::fetchWhere($data, self::$table[6]);
		}

		public static function fetchSingleDepartment($data) 
		{
			return parent::fetchWhere($data, self::$table[3]);
		}

		public static function fetchSingleUser($data) 
		{
			return parent::fetchWhere($data, self::$table[0]);
		}





		// FETCH SINGLE WHERE WITH JOIN TABLE

		public static function fetchSingleBook($data) 
		{
			return parent::fetchMultiJoinWhere($data, self::$table[2], self::$table[1], self::$table[6], 'category_id', 'publisher_id');
		}

		public static function fetchSingleBorrower($data) 
		{
			return parent::fetchJoinWhere($data, self::$table[4], self::$table[3], 'department_id');
		}


		// FETCH ALL WHERE WITH TWO JOIN TABLE
		public static function fetchBookBorrowers($data) 
		{
			return parent::fetchTwoJoinWhere(self::$table[5], self::$table[4], self::$table[3], 'idnumber', 'department_id', $data);
		}




		// FETCH ALL WHERE WITH THREE JOIN TABLE
		public static function fetchBorrowerHistory($data) 
		{
			return parent::fetchThreeJoinWhere(self::$table[5], self::$table[2], self::$table[1], self::$table[4], 'accession_id', 'category_id', 'idnumber', $data);
		}



		// FETCH ALL WHERE WITH JOIN TABLE
		public static function fetchBroadcastBooks($data) 
		{
			return parent::fetchAllJoinWhere($data, self::$table[2], self::$table[1], 'category_id');
		}

		public static function fetchAllCategoryBooks($data) 
		{
			return parent::fetchAllJoinWhere($data, self::$table[2], self::$table[1], 'category_id');
		}	


		





		// SEARCH BOOK IN OPAC
		public static function searchCirculationBook($data) 
		{
			return parent::searchBookCirculation($data, self::$table[2], self::$table[1], self::$table[6], 'category_id', 'publisher_id');
		}

		public static function searchAllCirculationBook($data) 
		{
			return parent::searchAllBookCirculation($data, self::$table[2], self::$table[1], self::$table[6], 'category_id', 'publisher_id');
		}




		public static function searchReservedBook($data) 
		{
			return parent::searchBookReserved($data, self::$table[2], self::$table[1], self::$table[6], 'category_id', 'publisher_id');
		}
		
		public static function searchAllReservedBook($data) 
		{
			return parent::searchAllBookReserved($data, self::$table[2], self::$table[1], self::$table[6], 'category_id', 'publisher_id');
		}

		
	}
