<?php 

	class Router 

	{

		private static $instance = null;
		private $routes = [];


		public static function instance() {
			if(self::$instance === null){
				self::$instance = new self();
			}

			return self::$instance;
		}

		public static function get($uri, $callback) {
			self::instance()->routes[$uri] = $callback;
		}

		public static function routes($uri) {


			if(isset(self::$instance->routes[$uri])){
				self::$instance->routes[$uri]();
			} else {
				require 'error.php';
			}
		}

	}


	Router::get('admin-dashboard', function(){
		require 'admin/dashboard.php';
	});

	Router::get('admin-maintenance', function(){
		require 'admin/maintenance.php';
	});

	Router::get('admin-student', function(){
		require 'admin/student.php';
	});

	Router::get('admin-teacher', function(){
		require 'admin/teacher.php';
	});

	Router::get('admin-bookavailable', function(){
		require 'admin/bookavailable.php';
	});

	Router::get('admin-bookborrowed', function(){
		require 'admin/bookborrowed.php';
	});

	Router::get('admin-bookreturned', function(){
		require 'admin/bookreturned.php';
	});
	
	Router::get('login', function(){
		require 'admin/loginform.php';
	});

	Router::get('logout', function(){
		require 'admin/logout.php';
	});

	// OPAC

	Router::get('index.php', function(){
		require 'opac/homepage.php';
	});

	Router::get('opac-homepage', function(){
		require 'opac/homepage.php';
	});

	Router::get('opac-singlepage', function(){
		require 'opac/singlepage.php';
	});
	
	


