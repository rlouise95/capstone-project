<?php 

	class Model {

		private static $config = [
			'host' => 'localhost',
			'username' => 'root',
			'password' => '',
			'dbname' => 'library_system'
		];

		// SET CONNECTION METHOD
		private static function conn()
		{

			try {

				$pdo = new PDO('mysql:host='.self::$config['host'].';dbname='.self::$config['dbname'], self::$config['username'], self::$config['password'] );
				$pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_OBJ);
				return $pdo;
				
			} catch (PDOException $e) {

				die($e->getMessage());

			}

		}

		// TOTAL ALL METHOD
		protected static function addAll($table) {

			$sql = "SELECT SUM(fines) AS fines FROM {$table}";

			$stmt = self::conn()->prepare($sql);

			$stmt->execute();

			return $stmt->fetch();
		}


		// COUNT ALL METHOD
		protected static function countAll($table) {

			$sql = "SELECT * FROM {$table}";

			$stmt = self::conn()->prepare($sql);

			$stmt->execute();

			return $stmt->rowCount();
		}



		// COUNT WHERE METHOD
		protected static function count($data, $table) {

			$condition = [];
			foreach ($data as $key => $value) {
				$condition[] = $key.' = ?';
			}

			$column = implode(' && ', $condition);
			
			$sql = "SELECT * FROM {$table} WHERE {$column}";

			$stmt = self::conn()->prepare($sql);

			$stmt->execute(array_values($data));

			return $stmt->rowCount();

		}


		// COUNT WHERE WITH JOIN METHOD
		protected static function countJoinWhere($data, $table, $table2, $relation_column) {

			$condition = [];
			foreach ($data as $key => $value) {
				$condition[] = $key.' = ? ';
			}

			$column = implode(' && ', $condition);
			
			$sql = "SELECT * FROM {$table} INNER JOIN {$table2} ON {$table}.{$relation_column} = {$table2}.{$relation_column} WHERE {$column}";

			$stmt = self::conn()->prepare($sql);

			$stmt->execute(array_values($data));

			return $stmt->rowCount();

		}



		// FETCH SINGLE WHERE METHOD
		protected static function fetchWhere($data, $table) {

			$column = implode(',', array_keys($data));
			
			$sql = "SELECT * FROM {$table} WHERE {$column} = ?";

			$stmt = self::conn()->prepare($sql);

			$stmt->execute(array_values($data));

			return $stmt->fetch();

		}



		// FETCH SINGLE WHERE WITH JOIN METHOD
		protected static function fetchJoinWhere($data, $table, $table2, $relation_column) {

			$column = implode(',', array_keys($data));
			
			$sql = "SELECT * FROM {$table} INNER JOIN {$table2} ON {$table}.{$relation_column} = {$table2}.{$relation_column} WHERE {$column} = ?";

			$stmt = self::conn()->prepare($sql);

			$stmt->execute(array_values($data));

			return $stmt->fetch();

		}



		// FETCH SINGLE WHERE WITH MULTIPLE JOIN METHOD
		protected static function fetchMultiJoinWhere($data, $table, $table2, $table3, $relation_column, $relation_column2) {

			$column = implode(',', array_keys($data));
			
			$sql = "SELECT * FROM {$table} INNER JOIN {$table2} ON {$table}.{$relation_column} = {$table2}.{$relation_column} INNER JOIN {$table3} ON {$table}.{$relation_column2} = {$table3}.{$relation_column2} WHERE {$column} = ?";


			$stmt = self::conn()->prepare($sql);

			$stmt->execute(array_values($data));

			return $stmt->fetch();

		}




		// FETCH ALL WHERE WITH JOIN METHOD
		protected static function fetchAllJoinWhere($data, $table, $table2, $relation_column) {

			$condition = [];
			foreach ($data as $key => $value) {
				$condition[] = $key.' = ? ';
			}

			$column = implode(' && ', $condition);


			
			$sql = "SELECT * FROM {$table} INNER JOIN {$table2} ON {$table}.{$relation_column} = {$table2}.{$relation_column} WHERE {$column}";

			$stmt = self::conn()->prepare($sql);

			$stmt->execute(array_values($data));

			return $stmt->fetchAll();

		}


		




		// FETCH ALL WHERE WITH TWO JOIN METHOD
		protected static function fetchTwoJoinWhere($table, $table2, $table3, $relation_column, $relation_column2, $order_column) {

			$column = implode(',', array_keys($order_column));
			
			$sql = "SELECT * FROM {$table} INNER JOIN {$table2} ON {$table}.{$relation_column} = {$table2}.{$relation_column} 
					INNER JOIN {$table3} ON {$table2}.{$relation_column2} =  {$table3}.{$relation_column2}
					WHERE {$column} = ?";


			$stmt = self::conn()->prepare($sql);

			$stmt->execute(array_values($order_column));

			return $stmt->fetchAll();

		}



		// FETCH ALL WHERE WITH THREE JOIN METHOD
		protected static function fetchThreeJoinWhere($table, $table2, $table3, $table4, $relation_column, $relation_column2, $relation_column3, $order_column) {

			$column = implode(',', array_keys($order_column));
			
			$sql = "SELECT * FROM {$table} INNER JOIN {$table2} ON {$table}.{$relation_column} = {$table2}.{$relation_column} 
					INNER JOIN {$table3} ON {$table2}.{$relation_column2} =  {$table3}.{$relation_column2}
					INNER JOIN {$table4} ON {$table}.{$relation_column3} =  {$table4}.{$relation_column3}
					WHERE {$table}.{$column} = ?";


			$stmt = self::conn()->prepare($sql);

			$stmt->execute(array_values($order_column));

			return $stmt->fetchAll();



		}





		// FETCH ALL METHOD
		protected static function fetch($table, $order_column) {

			$sql = "SELECT * FROM {$table} ORDER BY {$order_column} DESC";

			$stmt = self::conn()->query($sql);

			$stmt->execute();

			return $stmt->fetchAll();
		}





		// FETCH ALL WITH JOIN METHOD
		protected static function fetchJoin($table, $table2, $relation_column, $order_column) {

			$sql = "SELECT * FROM {$table} INNER JOIN {$table2} ON {$table}.${relation_column} = {$table2}.${relation_column} ORDER BY {$table}.{$order_column} DESC";

			$stmt = self::conn()->query($sql);

			$stmt->execute();

			return $stmt->fetchAll();
		}




		// FETCH ALL WITH TWO JOIN METHOD
		protected static function fetchtwoJoin($table, $table2, $table3, $relation_column, $relation_column2, $order_column) {

			$sql = "SELECT * FROM {$table} INNER JOIN {$table2} ON {$table}.${relation_column} = {$table2}.${relation_column} INNER JOIN {$table3} ON {$table}.${relation_column2} = {$table3}.${relation_column2} ORDER BY {$table}.{$order_column} DESC";

			$stmt = self::conn()->query($sql);

			$stmt->execute();

			return $stmt->fetchAll();
		}




		// FETCH ALL WITH DISTINCT JOIN METHOD
		protected static function fetchAllDistinctJoin($table, $table2, $table3, $relation_column, $relation_column2, $order_column) {

			$sql = "SELECT DISTINCT {$table3}.category_name , {$table2}.accession_id, {$table2}.title, {$table2}.author, {$table2}.borrowedcopies FROM {$table} 
					INNER JOIN {$table2} ON {$table}.${relation_column} = {$table2}.${relation_column}
					INNER JOIN {$table3} ON {$table2}.${relation_column2} = {$table3}.${relation_column2} 
					ORDER BY {$table}.{$order_column} DESC";

			$stmt = self::conn()->query($sql);

			$stmt->execute();
			

			return $stmt->fetchAll();
		}




		// INSERT METHOD
		protected static function insert($data, $table) {


			$column = implode(',', array_keys($data));

			$placeholder = implode(',', array_map(function(){
				return "?";
			}, $data));


			$sql = "INSERT INTO {$table}($column) VALUES ($placeholder)";

			$stmt = self::conn()->prepare($sql);


			$stmt->execute(array_values($data));

		}




		// UPDATE METHOD
		protected static function update($data, $table, $id) {

			$condition = [];
			foreach($data as $key => $value){
				$condition[] = $key.' = ?';
			}
			$column = implode(', ', $condition);


			$condition2 = [];
			foreach($id as $key => $value){
				$condition2[] = $key.' = '.$value;
			}
			$column2 = implode('&& ', $condition2);

			$sql = "UPDATE {$table} SET {$column} WHERE {$column2}";


			$stmt = self::conn()->prepare($sql);
			

			$stmt->execute(array_values($data));

		}




		// DELETE METHOD
		protected static function delete($data, $table) {

			$column = implode(',', array_keys($data));

			$sql = "DELETE FROM {$table} WHERE {$column} = ?";

			$stmt = self::conn()->prepare($sql);

			$stmt->execute(array_values($data));

		}

		// DELETE METHOD
		protected static function deleteMultipleColumn($data, $table) {

			$condition = [];
			foreach($data as $key => $value){
				$condition[] = $key.' = ?';
			}

			$column = implode(' && ', $condition);

			$sql = "DELETE FROM {$table} WHERE {$column}";

			$stmt = self::conn()->prepare($sql);

			$stmt->execute(array_values($data));

		}




		// SEARCH METHOD
		protected static function searchBookCirculation($data, $table, $table2, $table3, $relation_column, $relation_column2) {


			$sql = "SELECT * FROM {$table} 
					INNER JOIN {$table2} ON {$table}.{$relation_column} = {$table2}.{$relation_column} 
					INNER JOIN {$table3} ON {$table}.{$relation_column2} = {$table3}.{$relation_column2} 
					WHERE books.category_id = {$data['categories.category_id']} && books.type = 'Circulation'
					&& books.broadcast = 1 && {$data['filterkey']} LIKE ?  ";
		

			$value = "%".$data['searchkey']."%";

			$stmt = self::conn()->prepare($sql);

			$stmt->execute([$value]);


			return $stmt->fetchAll();


		}

		protected static function searchAllBookCirculation($data, $table, $table2, $table3, $relation_column, $relation_column2) {


			$sql = "SELECT * FROM {$table} 
					INNER JOIN {$table2} ON {$table}.{$relation_column} = {$table2}.{$relation_column} 
					INNER JOIN {$table3} ON {$table}.{$relation_column2} = {$table3}.{$relation_column2} 
					WHERE books.type = 'Circulation'
					&& books.broadcast = 1 && {$data['filterkey']} LIKE ?  ";
		

			$value = "%".$data['searchkey']."%";

			$stmt = self::conn()->prepare($sql);

			$stmt->execute([$value]);


			return $stmt->fetchAll();


		}







		protected static function searchBookReserved($data, $table, $table2, $table3, $relation_column, $relation_column2) {


			$sql = "SELECT * FROM {$table} 
					INNER JOIN {$table2} ON {$table}.{$relation_column} = {$table2}.{$relation_column} 
					INNER JOIN {$table3} ON {$table}.{$relation_column2} = {$table3}.{$relation_column2} 
					WHERE books.category_id = {$data['categories.category_id']} && books.type = 'Reserved'
					&& books.broadcast = 1 && {$data['filterkey']} LIKE ?  ";
		

			$value = "%".$data['searchkey']."%";

			$stmt = self::conn()->prepare($sql);

			$stmt->execute([$value]);


			return $stmt->fetchAll();


		}


		protected static function searchAllBookReserved($data, $table, $table2, $table3, $relation_column, $relation_column2) {


			$sql = "SELECT * FROM {$table} 
					INNER JOIN {$table2} ON {$table}.{$relation_column} = {$table2}.{$relation_column} 
					INNER JOIN {$table3} ON {$table}.{$relation_column2} = {$table3}.{$relation_column2} 
					WHERE books.type = 'Reserved'
					&& books.broadcast = 1 && {$data['filterkey']} LIKE ?  ";
		

			$value = "%".$data['searchkey']."%";

			$stmt = self::conn()->prepare($sql);

			$stmt->execute([$value]);


			return $stmt->fetchAll();


		}


	}
