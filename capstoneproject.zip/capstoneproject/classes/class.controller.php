<?php 

	class Controller extends Model {

		
		private static $table = ['users', 'categories', 'books', 'department', 'borrowers', 'book_borrowed', 'publishers', 'rules', 'book_returned'];


		// INSERT
		public static function insertCategory($data) {
			parent::insert($data, self::$table[1]);
		}

		public static function insertPublisher($data) {
			parent::insert($data, self::$table[6]);
		}

		public static function insertDepartment($data) {
			parent::insert($data, self::$table[3]);
		}

		public static function insertBook($data) {
			 parent::insert($data, self::$table[2]);
		}

		public static function insertUser($data) {
			 parent::insert($data, self::$table[0]);
		}

		public static function insertBorrower($data) {
			 parent::insert($data, self::$table[4]);
		}

		public static function insertBorrowBook($data) {
			 parent::insert($data, self::$table[5]);
		}

		public static function insertBookReturn($data) {
			 parent::insert($data, self::$table[8]);
		}

		public static function insertBulkBorrowers($data) {
			 parent::insert($data, self::$table[4]);
		}




		// UPDATE 
		public static function updateRules($data, $id) {
			parent::update($data, self::$table[7], $id);
		}
		public static function updateCategory($data, $id) {
			parent::update($data, self::$table[1], $id);
		}

		public static function updatePublisher($data, $id) {
			parent::update($data, self::$table[6], $id);
		}

		public static function updateDepartment($data, $id) {
			parent::update($data, self::$table[3], $id);
		}

		public static function updateBook($data, $id) {
			parent::update($data, self::$table[2], $id);
		}

		public static function updateBorrower($data, $id) {
			parent::update($data, self::$table[4], $id);
		}

		public static function updateUser($data, $id) {
			parent::update($data, self::$table[0], $id);
		}

		public static function setNewSecurity($data, $id) {
			parent::update($data, self::$table[0], $id);
		}

		public static function broadcastBook($data, $id) {
			parent::update($data, self::$table[2], $id);
		}




		// DELETE
		public static function deleteCategory($data) {
			parent::delete($data, self::$table[1]);
		}

		public static function deletePublisher($data) {
			parent::delete($data, self::$table[6]);
		}

		public static function deleteDepartment($data) {
			parent::delete($data, self::$table[3]);
		}

		public static function deleteBorrower($data) {
			parent::delete($data, self::$table[4]);
		}

		public static function deleteUser($data) {
			parent::delete($data, self::$table[0]);
		}

		public static function deleteBorrowedBook($data) {
			parent::deleteMultipleColumn($data, self::$table[5]);
		}

		public static function deleteBook($data) {
			parent::delete($data, self::$table[2]);
		}


		
	}






